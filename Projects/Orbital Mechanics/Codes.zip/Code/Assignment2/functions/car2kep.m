function [a, e, i, OM, om, th, N] = car2kep(r, v, mu)

% car2kep.m - Conversion from Cartesian coordinates to Keplerian elements
%
% PROTOTYPE:
%       [a, e, i, OM, om, th] = car2kep(r, v, mu)
%
% DESCRIPTION:
%       Conversion from Cartesian coordinates to Keplerian elements. Angles in
%       radians.
%
% INPUT:
% r [3x1]       Position vector [km]
% v [3x1]       Velocity vector [km/s]
% mu [1x1]      Planetary Constant (mu = mass * G) [km^3/s^2]
%
% OUTPUT:
% a [1x1]       Semi-major axis [km]
% e [1x1]       Eccentricity [-]
% i [1x1]       Inclination [rad]
% OM [1x1]      RAAN [rad]
% om [1x1]      Pericentre anomaly [rad]
% th [1x1]      True anomaly [rad]
% N [1x1]       Norm of Nodal Axis [-]
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
% ---------------------------------------------------------------------------------

I = [1 0 0]';
J = [0 1 0]';
K = [0 0 1]';

%% 1 position vector norm & velocity vector norm
r_norm = norm(r);
v_norm = norm(v);

%% 2 specific angular moment
h = cross(r,v);
h_norm = norm(h);

%% Inclination
i = acos(dot(h,K)/h_norm);

%% Eccentricity
e = 1/mu * ((v_norm^2 - mu/r_norm)*r - (dot(r,v))*v);
e_norm = norm(e);

%% Semi-major axis & energy
Eps = 1/2 * v_norm^2 - mu/r_norm;
a = -mu/(2*Eps);

%% nodal axis
N = cross(K,h);
N_norm = norm(N);

%% RAAN
if dot(N,J) >= 0
 OM = acos(dot(N,I)/N_norm);
else
    OM = 2*pi - acos(dot(N,I)/N_norm);
end
if i == 0
    OM = 0;
    N = [1;0;0];
    N_norm = norm(N);
end

if dot(e,K) >= 0
    om = acos(dot(N,e)/(N_norm * e_norm));
else
    om = 2*pi -acos(dot(N,e)/(N_norm * e_norm));
end

if dot(v,r)/r_norm >=0
    th = acos(dot(r,e)/(r_norm * e_norm));
else
    th = 2*pi - acos(dot(r,e)/(r_norm * e_norm));
end

e = e_norm;
end
