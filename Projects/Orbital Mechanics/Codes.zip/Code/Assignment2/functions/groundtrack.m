function [alpha, delta, lon, lat] = groundtrack(a,e,i,OM,om,th,long0,tspan,parameters,t0)

% groundtrack.m - calculates the parameters needed to plot a groundtrack
%
% PROTOTYPE: 
%       [alpha, delta, lon, lat] = groundtrack(a,e,i,OM,om,th,long0, tspan,omega_E,mu_E,t0)
%
% DESCRIPTION: 
%       Function which computes the ground track of an orbit around Earth
% 
% INPUT
% a [1x1]           Semi-Major Axis [Km]
% e [1x1]           Eccentricity [-]
% i [1x1]           Inclination [rad]
% OM  [1x1]         Right Ascension [rad]
% om  [1x1]         Perigee Anomaly [rad]
% th  [1x1]         True Anomaly    [rad]
% long0 [1x1]       Greenwich longitude: Normally 0
% tspan [1xN]       tspan = linspace(0, N*T_orbit, N*1000) with N = number of orbit
% parameters [8x1]  Vector containing the physical parameters needed to compute  
%                   the perturbating acceleration:  [mu_E, R_E, J2, C_D, A_m, w_E_vec]
%                   - mu_E[1x1]:     Earth Planetary Constant [Km^3/s^2]
%                   - R_E[1x1]:      Earth Mean Radius [Km]
%                   - J2[1x1]:       Second Zonal Armonic which describes the oblateness of 
%                                    the Earth Spheroid
%                   - C_D[1x1]:      Drag Coefficient
%                   - A_m[1x1]:      Surface per unit Mass of the s/c [m^2/Kg]
%                   - w_E_vec[3x1]:  Vector of Earth mean Rotational Speed --> [0; 0; w_E] 
%                                    w_E: Earth mean Rotational speed around its z axis
%                                    value = 15.04 °/h --> in [rad/s] = deg2rad(15.04/3600)
% t0 [1x1]          Initial Time  [s]

%
% OUTPUT
% alpha [Nx1]       Right ascension in Earth Centred Equatorial Inertial frame [rad]
% delta [Nx1]       Declination in Earth Centred Equatorial Inertial frame [rad]
% lon   [Nx1]       Longitude with respect to rotating Earth [rad]
% lat   [Nx1]       Latitude with respect to rotating Earth [rad]
% 
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
% ------------------------------------------------------------------------------------------------------

% Physical Parameters
mu_E = parameters(1);       % Earth Planetary COnstant [Km^3/s^2]
omega_E = parameters(8);    % Earth Rotational Speed [rad/s]

% Cartesian Parameters
[r0, v0] = kep2car(a,e,i,OM,om,th,mu_E);
y0 = [ r0, v0];

% Set options for the ODE solver
options = odeset('RelTol',1e-13, 'AbsTol', 1e-14);
% Perform the integration
[T, Y] = ode113(@(t,y) ode_2bp(t,y,mu_E), tspan, y0, options);
% Y has in the first 3 column the position vectors X, Y, Z, then in the
% last 3 column the three velocity components Vx, Vy, Vz.
r = Y(:,1:3);

rnorm = (vecnorm(r'))';

% Declination
delta = asin(r(:,3)./(rnorm));

% Longitude of the Ascending Node
alpha = atan2(r(:,2), r(:,1));

% Longitude 
theta_g_t = long0 + omega_E*(T - t0);

lon = wrapToPi(alpha - theta_g_t);
lat = delta;
end
