function [globe] = plotPlanet(planetID, position, handle, scaleFactor)

% plotPlanet.m - Plots the planet
% 
% PROTOTYPE:
%      [globe] = plotPlanet(planetID, position, handle, scaleFactor) 
%
% DESCRIPTION: 
%       Plots  all the planets of the Solar System, Sun included, taking
%       the pictures from the folder 'textures'
% 
% INPUT 
% planetID      scalar      planet identity code in the function
% position      array [3x1] planet position in the reference frame [km]
% handle        structure   structure with axes informations
% scaleFactor   scalar      scale factor between sun and planet
%
% OUTPUT
% globe        structure       surface with planet images
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
%---------------------------------------------------------------------------------------------------


% Axes choice
    if nargin<3
        HAXIS = gca;
    elseif ishandle(handle)==0
            msg = 'The figure handle is not valid';
            error(msg)
    else
        try
            HAXIS=gca(handle);
        catch
            HAXIS=handle;  
        end
        hold on
    end
    %--------------------------------------------------------------------------
    if nargin<4
        if planetID == 10
            scaleFactor = 1;
        else
            scaleFactor = astroConstants(20+planetID)/astroConstants(3);
        end
    end
    
    planetNames = {'Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto', 'Sun'};
    


    R_planet = astroConstants(3)*scaleFactor; % Planet radius w.r.t. sun [km]
    npanels = 360; % Number of globe panels around the equator [deg/panel] = [360/npanels]
    erad=R_planet; % equatorial radius [km]
    prad=R_planet; % polar radius [km]
    % circular planet
    hold on;
    axis equal;
    axis vis3d;
   
    [x,y,z] = ellipsoid(position(1), position(2), position(3), erad, erad, prad, npanels);
    globe = surf(HAXIS, x,y,z,'FaceColor','none','EdgeColor',0.5*[1 1 1]);
    
    cdata=imread(sprintf('%s.jpg',planetNames{planetID})); % Load Earth image for texture map
  
    globe.FaceColor = 'texturemap';
    globe.CData = flip(cdata); % W/o flip() the texture looks upside down
    globe.EdgeColor = 'none';

    rotate(globe,[0 0 1],180, position);

    

end
