function dy = ode_2bodyPerturbGauss(~, y,parameters,ref)

% ode_2bodyPerturbGauss - ODE system for the perturbed two body problem (Keplerian problem)using the Gauss Planetary Equations
% 
% PROTOTYPE:
%       dy = ode_2bodyPerturbGauss(~, y,parameters,ref)
%
% DESCRIPTION:
%       ODE system for the perturbed two body problem (Keplerian problem) using 
%       the Gauss Planetary Equations considering as perturbations the one
%       due to oblateness of Earth spheroid (J2) and the one due to
%       atmospheric Drag
%
% INPUT
%   y[6x1]            State of the Body (rx, ry, rz, vx, vy, vz) [Km Km/s]
%   parameters[8x1]   Vector containing the physical parameters needed to compute the perturbating 
%                     acceleration:       [mu_E, R_E, J2, C_D, A_m, w_E_vec]
%                       - mu_E:     Earth Planetary Constant [Km^3/s^2]
%                       - R_E:      Earth Mean Radius [Km]
%                       - J2:       Second Zonal Armonic which describes the oblateness of
%                                   the Earth Spheroid
%                       - C_D:      Drag Coefficient
%                       - A_m:      Surface per unit Mass of the s/c [m^2/Kg]
%                       - w_E_vec:  Vector of Earth Mean Rotational Speed --> [0; 0; w_E] [3x1]
%                                   w_E: Earth mean Rotational speed around its z axis
%                                        value = 15.04 °/h --> in [rad/s] = deg2rad(15.04/3600)
%   ref                switch for the two possible reference frame in
%                      which calculate the perturbating acceleration: 
%                      RSW --> Radial-Transversal-Out of Plane
%                      TNH --> Tangential-Normal-Out of Plane
%
% OUTPUT
%   dy[6x1]            Derivative of the state [m/s^2, m/s^3]
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version 
% -----------------------------------------------------------------------------

% Physical Parameters
mu_E = parameters(1); % Gravitational parameter of the primary [m^3/s^2]
R_E = parameters(2); % Earth Radius [Km]
J2 = parameters(3); % Second Zonal Armonic which describes the oblateness of the Earth Spheroid
C_D = parameters(4); % Drag Coefficient
A_m = parameters(5); % Surface per unit mass [m^2/kg]
w_E = parameters(8); % Earth Mean Angular Velocity Vector [3x1]
w_E_v = w_E * [0 0 1]';
% y[6x1] Keplerian Elements of the orbit
a = y(1);  % Semi-major axis [Km]
e = y(2);  % Eccentricity
i = y(3);  % Inclination [rad]
OM = y(4); % RAAN [rad]
om = y(5); % Argument of Pericentre [rad] 
th = y(6); % True Anomaly [rad]
[r_v, v_v] = kep2car(a,e,i,OM,om,th,mu_E); % Cartesian elements of the orbit

% Cartesian J2 perturbation
% Variation of orbital elements:
b = a * sqrt(1-e^2);
p = b^2/a;
n = sqrt(mu_E/a^3);
h = n*a*b;
th_star = th + om;
r = p/(1+e*cos(th)); % Magnitude of the position vector [Km]
v = sqrt(2*mu_E/r - mu_E/a); % Magnitude of the Velocity vector [Km/s]
% Components of the position vector in Cartesian ref. frame
x = r_v(1);
y = r_v(2);
z = r_v(3);

% Perturbating acceleration due to J2 effect in Cartesian ref. frame
a_J2_CAR = 3/2 *(J2*mu_E*R_E^2)/(r^4) *[(x/r) *(5*(z^2)/(r^2)-1); (y/r) *(5*(z^2)/(r^2)-1); z/r *(5*(z^2)/(r^2)-3)];

% acceleration drag
alt = r - R_E; % Altitude (km)
rho = atmosphere(alt); % Air density from US Standard Model (kg/m^3)
Vrel = v_v - cross(w_E_v,r_v); % Velocity relative to the atmosphere (km/s)
vrel = norm(Vrel); % Speed relative to the atmosphere (km/s)
uv = Vrel/vrel; % Relative velocity unit vector
a_DRAG_CAR = -C_D*A_m*rho*(1000 * vrel)^2/2*uv; % Acceleration due to drag (m/s^2)

a_CAR = a_J2_CAR + a_DRAG_CAR/1000; % Total perturbating acceleration [Km/s^2]

% To pass in the TNH ref frame and RSW ref frame respectively from the
% Cartesian Ref. Frame
[TNH, RSW] = vec_ref_plane_change(r_v,v_v);
a_TNH = TNH' * a_CAR; % Perturbating Acceleration Vector in TNH ref.frame
a_RSW = RSW' * a_CAR; % Perturbating Acceleration Vector in RSW ref.frame

a_t = a_TNH(1);
a_n = a_TNH(2);
a_h = a_TNH(3);

a_r = a_RSW(1);
a_s = a_RSW(2);
a_w = a_RSW(3);

switch ref
  case 'TNH'
    da  = 2*a^2*v/mu_E * a_t;
    de = 1/v* ( 2*(e+cos(th))*a_t - r/a*sin(th)*a_n );
    di  = r*cos(th_star)/h * a_h;
    dOM = r*sin(th_star)/(h*sin(i)) * a_h;
    dom = 1/(e*v) * ( 2*sin(th)*a_t + (2*e + r/a*cos(th))*a_n ) - r*sin(th_star)*cos(i)/(h*sin(i))*a_h;
    dth = h/r^2 - 1/(e*v) * ( 2*sin(th)*a_t + (2*e + r/a*cos(th))*a_n );


  case 'RSW'
    da = 2*(a^2)/h*(e*sin(th)*a_r+p/r*a_s);
    de = 1/h*(p*sin(th)*a_r+((p+r)*cos(th)+r*e)*a_s);
    di = r*cos(th_star)/h*a_w;
    dOM = r*sin(th_star)/(h*sin(i))*a_w;
    dom = 1/(h*e)*(-p*cos(th)*a_r+(p+r)*sin(th)*a_s)-r*sin(th_star)*cos(i)/(h*sin(i))*a_w;
    dth = h/r^2+1/(e*h)*(p*cos(th)*a_r-(p+r)*sin(th)*a_s);
 
end
% Derivative of the Keplerian Elements of the orbit
dy = [da; de; di; dOM; dom; dth];
   
end