function [a] = repeating_groundtrack(k, m, omega_E, mu_E)

% repeating_groundtrack.m - Semi-major axis of an orbit with repeating groundtrack
% 
% PROTOTYPE:
%       [a] = repeating_groundtrack(k, m, omega_E, mu_E)
%  
% DESCRIPTION: 
%       Function that computes the required Semi-Major Axis a from a repeating
%       groundtrack with k satellite revolution and m Earth revolution
%
% INPUT:
%   k[1x1]         Number of satellite revolutions before crossing again the
%                  same point on Earth surface
%   m[1x1]         Number of Earth revolutions which occurs before that the s/c
%                  crosses again the same point on Earth surface
%   omega_E[1x1]   Earth Rotational Angular Velocity [rad/s]
%   mu_E[1x1]      Earth Planetary Constant (mu = mass * G) [km^3/s^2]
%
% OUTPUT
%   a[1x1]         Semi-major axis of the s/c orbit such that it has a repeating
%                  groundtrack [km]
% 
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
% -----------------------------------------------------------------------------------
 
% Mean Motion
n = omega_E*(k/m);
% Semi-Major Axis
a_cube = mu_E/n^2;
a = a_cube^(1/3);

end