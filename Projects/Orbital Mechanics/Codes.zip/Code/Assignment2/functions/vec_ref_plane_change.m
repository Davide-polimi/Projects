function[TNH, RSW] = vec_ref_plane_change(r,v)

% vec_ref_plane_change.m - conversion from Cartesian ref.frame to TNH and RSW ref.frame
% 
% PROTOTYPE:
%       [TNH, RSW] = vec_ref_plane_change(r,v)
% 
% DECRIPTION:
%       Function to pass from Cartesian ref.frame to TNH (Tangential-Normal-Out of Plane) 
%       or to RSW (Radial-Transversal-Out of Plane)
%       
% INPUT
%   r[3x1]      Position Vector [rx,ry,rz] in the Cartesian ref.frame   [km]    
%   v[3x1]      Velocity Vector [vx, vy, vz] in the Cartesian ref.frame [km/s]
% 
% OUTPUT
%   TNH[3x3]    Rotation Matrix to pass from Cartesian ref.frame to TNH ref.frame
%   RSW[3x3]    Rotation Matrix to pass from Cartesian ref.frame to RSW ref.frame
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
% ------------------------------------------------------------------------------------------

% Unit Vectors of TNH ref.frame
t = v/norm(v);
h = cross(r,v)/norm(cross(r,v));
n = cross(h,t);
TNH = [t n h]; % Rotation Matrix

% Unit Vectors of RSW ref.frame
r_un = r/norm(r);
w = cross(r,v)/norm(cross(r,v));
s = cross(w,r_un);
RSW = [r_un s w]; % Rotation Matrix

end