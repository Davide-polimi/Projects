function [kep,car] = sat_ephemeris(SAT_TLE,mu_E)
% sat_ephemeris.m - recovers the keplerian parameters of interest from downloaded ephemeris
% 
% PROTOTYPE:
%       [kep,car] = sat_ephemeris(SAT_TLE,mu_E)
% 
% DESCRIPTION: 
%       function to recover the orbital parameters of a real
%       satellite/debris from the ephemeris downloaded from the NASA
%       website HORIZONS.
%
% INPUT
% SAT_TLE[Nx12]:    Matrix containing all the orbital parameters organized in columns
%                   of the chosen celestial object. Respectively, the columns are
%                       - 1st:  Eccentricity
%                       - 2nd:  Periapsis Distance, QR [Km]
%                       - 3rd:  Inclination, i [degrees]
%                       - 4th:  Longitude of Ascending Node, OMEGA (RAAN) [degree]
%                       - 5th:  Argument of Perigee, W [degree]
%                       - 6th:  Time of Periapsis, Tp [Julian Day]
%                       - 7th:  Mean Motion, N [degrees/sec]
%                       - 8th:  Mean Anomaly, M [degrees]
%                       - 9th:  True anomaly, nu [degrees]
%                       - 10th: Semi-major axis, a [km]
%                       - 11th: Apoapsis distance [km]
%                       - 12th: Sidereal orbit period [sec]
%                       N = depends on the number of days selected
% mu_E[1x1]:         Earth Planetary Constant (mu = mass * G) [km^3/s^2]
%
% OUTPUT
% kep[Nx6]           Matrix containing the orbital parameters of interest: 
%                    [a, e, i, OM, om, th] where: 
%                      - a     Semi-Major axis [Km]     [14401x1]
%                      - e     Eccentricity     [14401x1]
%                      - i     Inclination [rad]    [14401x1]
%                      - OM    Longitude of Ascending Node [rad]    [14401x1]
%                      - om    Argument of Perigee [rad]    [14401x1]
%                      - th    True Anomaly [rad]   [14401x1]
% car[Nx6]           Matrix containing the 3 components of the position vector (r) and
%                    the 3 components of the velocity vector (v) at every instant selected for the
%                    TLE. Dimensions: [14401x6]
%                    Example: [ x; y; z; vx; vy; vz]
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version
% ---------------------------------------------------------------------------------

% Keplerian Parameters
e = SAT_TLE(:,1);               % Eccentricity
i = deg2rad(SAT_TLE(:,3));      % Inclination [rad]
OM = deg2rad(SAT_TLE(:,4));     % Longitude to Ascending Node [rad]
om = deg2rad(SAT_TLE(:,5));     % Argument of perigee [rad]
a = SAT_TLE(:,10);              % Semi-major Axis [Km]
th = deg2rad(SAT_TLE(:,9));     % True Anomaly [rad]
kep = [a e i OM om th];

% Transform the orbital parameters in Cartesian parameters. The for cicle
% is needed as the function kep2car needs as input only scalar
car = zeros(max(size(SAT_TLE)),6);
for n = 1 : max(size(SAT_TLE))
    [ r(n,:), v(n,:)] = kep2car(a(n,1), e(n,1), i(n,1), OM(n,1), om(n,1), th(n,1), mu_E);
    car = [r v];
end

end