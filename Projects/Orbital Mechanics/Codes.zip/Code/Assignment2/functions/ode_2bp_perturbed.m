function dy = ode_2bp_perturbed( ~, y, parameters)

% ode_2bp_perturbed - ODE system for the perturbed two body problem (Keplerian problem)
% 
% PROTOTYPE:
%       dy = ode_2bodyPerturbGauss(~, y,parameters,ref)
%
% DESCRIPTION:
%       ODE system for the perturbed two body problem (Keplerian problem)
%       using Cartesian coordinates and considering as perturbations the one      
%       due to oblateness of Earth spheroid (J2) and the one due to
%       atmospheric Drag
%
% INPUT
%   y[6x1]            State of the Body (rx, ry, rz, vx, vy, vz) [Km Km/s]
%   parameters[8x1]   Vector containing the physical parameters needed to compute the perturbating 
%                     acceleration:       [mu_E, R_E, J2, C_D, A_m, w_E_vec]
%                       - mu_E[1x1]:     Earth Planetary Constant [Km^3/s^2]
%                       - R_E[1x1]:      Earth Mean Radius [Km]
%                       - J2[1x1]:       Second Zonal Armonic which describes the oblateness of
%                                        the Earth Spheroid
%                       - C_D[1x1]:      Drag Coefficient
%                       - A_m[1x1]:      Surface per unit Mass of the s/c [m^2/Kg]
%                       - w_E_vec[3x1]:  Vector of Earth Mean Rotational Speed --> [0; 0; w_E] 
%                                        w_E: Earth mean Rotational speed around its z axis
%                                        value = 15.04 °/h --> in [rad/s] = deg2rad(15.04/3600)
%
% OUTPUT
%   dy[6x1]            Derivative of the state [m/s^2, m/s^3]
%
% CONTRIBUTORS:
%       Davide Bellini
%       Edoardo Mensi Weingrill
%       Pietro Mirri
%       Gabriele Nuccio
% 
% VERSIONS
%       2023-12-27: First Version 
% -----------------------------------------------------------------------------

% Physical Parameters
mu_E = parameters(1);   % Earth Planetary Constant [m^3/s^2]
R_E = parameters(2);    % Earth Radius [Km]
J2 = parameters(3);     % Second Zonal Armonic which describes the oblateness of the Earth Spheroid
C_D = parameters(4);    % Drag Coefficient
A_m = parameters(5);    % Surface per unit mass [m^2/kg]
w_E = parameters(8);    % Earth Mean Angular Velocity Vector [3x1]
w_E_v = w_E * [0 0 1]'; 

% Cartesian coordinates
r_v = y(1:3);
v_v = y(4:6);

% Distance from the primary
r = norm(r_v);
x = r_v(1);
y = r_v(2);
z = r_v(3);

% Perturbating acceleration due to J2 effect in Cartesian ref. frame
a_J2_CAR = 3/2 *(J2*mu_E*R_E^2)/(r^4) *[(x/r) *(5*(z^2)/(r^2)-1); (y/r) *(5*(z^2)/(r^2)-1); z/r *(5*(z^2)/(r^2)-3)];

% Perturbating Acceleration due to Atmospheric Drag
alt = r - R_E;                  % Altitude (km)
rho = atmosphere(alt);          % Air density from US Standard Model (kg/m^3)
Vrel = v_v - cross(w_E_v,r_v);  % Velocity relative to the atmosphere (km/s)
vrel = norm(Vrel);              % Speed relative to the atmosphere (km/s)
uv = Vrel/vrel;                 % Relative velocity unit vector
a_DRAG_CAR = -C_D*A_m*rho*(1000 * vrel)^2/2*uv;     % Acceleration due to drag (m/s^2)

% Total perturbating acceleration
a = a_J2_CAR + a_DRAG_CAR/1000;

% Derivative of the state
dy = [v_v ; (-mu_E/r^3)*r_v+a];
end