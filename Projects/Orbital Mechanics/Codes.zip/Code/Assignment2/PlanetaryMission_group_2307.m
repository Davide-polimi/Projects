% Planetary Mission
clear; clc, close all;
addpath('functions\')
addpath('functions\textures\')
addpath('functions\timeConversion\')
addpath('functions\timeConversion\time')

set(groot, 'defaultTextInterpreter', 'latex')
set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
set(groot, 'defaultFigureColormap',parula(1000))
set(groot, 'defaultLegendInterpreter','latex')
%% DATA ASSIGNMENT 2
% Orbital Parameters given
a0 = 1.7264e04;             % Semi-Major Axis [Km]
e0 = 0.6098;                % Eccentricity [-]
i0 = deg2rad(49.257);       % Inclination [rad]

% We need to decide the other 3 keplerian parameters. Since there wasn't
% any apparent problem, we decided to consider them all zero
OM0 = deg2rad(0);           % Right Ascension of Ascending Node [rad]
om0 = deg2rad(0);           % Argument of Perigee [rad]
th0 = deg2rad(0);           % True Anomaly [rad]

% Parameters associated to atmospheric drag
cD = 2.1;                   % Drag Coefficient
A_m = 0.0113;               % Surface per unit mass [m^2/kg]

% Repeating Ground-Track ratio
k = 15;             % Satellite revolutions before returning in the same point on Earth surface
m = 4;              % Number of Earth revolutions 

% Physical Parameters
mu_E = astroConstants(13);  % Earth's gravitational parameter [km^3/s^2]
R_E = astroConstants(23);   % Earth's radius [km]
J2 = astroConstants(9);     % J2: Second Zonal Armonic which describes the oblateness of the
                            % Earth Spheroid
w_E = deg2rad(15.04/3600);  % Earth angular velocity [rad/s]
w_E_vec = w_E * [0;0;1];

% Build the vector parameters needed for the functions
parameters=zeros(8,1);
parameters(1) = mu_E;
parameters(2) = R_E;
parameters(3) = J2;
parameters(4) = cD;
parameters(5) = A_m;
parameters(6:8) = w_E_vec;

% Orbital Parameters
r_p = a0*(1-e0);                    % Radius of pericentre [Km]
r_a = a0*(1+e0);                    % Radius of apocentre [Km]
h = sqrt(mu_E*a0*(1-e0^2));         % Specific Angular Momentum [Km^2/s]
min_alt = r_p - R_E;                % Minimum Altitude from the ground [Km]
max_alt = r_a - R_E;                % Maximum Altitude from the ground [Km]
T_orbit = 2*pi*sqrt(a0^3/mu_E);     % Orbital Period [s]
long0 = 0;                          % Greenwich longitude [rad]

% Cartesian Parameters
[r0, v0] = kep2car(a0, e0, i0, OM0, om0, th0, mu_E);
y0 = [r0; v0];

tspan = 0 : 0.1 : T_orbit; % Set the tspan for the ODE propagation

%% UNPERTURBED ORBIT
% Set options for the ODE solver
options = odeset('RelTol',1e-13, 'AbsTol', 1e-14);
% Perform the integration
[T, Y] = ode113(@(t,y) ode_2bp(t,y,mu_E), tspan, y0, options);

% PLOT
hold on;
plotPlanet(3,[0,0,0],gca,astroConstants(23)/astroConstants(3));
grid on;
plot3(Y(:,1),Y(:,2),Y(:,3),'LineWidth',1.5)
xlabel('$X[km]$');
ylabel('$Y[km]$');
axis equal
zlabel('$Z[km]$');
title('$Unperturbed$ $Orbit$','FontSize',20)

%% GROUNDTRACK
t0 = 0;
% n_days = 5; -----> we used this to plot the ground track over different
%                    periods
% tspan_days = 1:0.5:n_days*24*3600;

% Set the tspan for the propagation of the ground track over 1 period
tspan_gt = 0:0.1:T_orbit; 

% Calling the function Groundtrack.m I can compute the Longitude and
% Latitude of the s/c in orbit
[alpha,delta,lon,lat] = groundtrack(a0,e0,i0,OM0,om0,th0, long0, tspan_gt, parameters, t0);

% Set longitude and latitude in degrees
lon = rad2deg(lon);
lat = rad2deg(lat);

% Plot the Groundtrack
figure()
hold on
cdata = imread('EarthTexture.jpg');
image(cdata, 'XData',[-180 180],'YData',[90 -90]);
plot( lon, lat,'r','LineStyle','none','Marker','.')
plot( lon(1), lat(1),'g','Linewidth',2,'LineStyle','none','Marker','square','MarkerSize',10)
plot( lon(end), lat(end),'y','Linewidth',2,'LineStyle','none','Marker','o','MarkerSize',10)
grid on
xlim([-180,180])
ylim([-90,90])
xlabel('$Longitude$ $[degrees]$', 'FontSize',15)
ylabel('$Latitude$ $[degrees]$', 'FontSize',15)
legend('$Ground-Track$','$Start$','$End$')
title('$Ground-Track$','FontSize',20)

%% UNPERTURBED & REPEATED GROUNDTRACK

% Calling the function Repeating_groundtrack,such that I can compute the semi-major
% axis of the orbit which presents a repeating ground-track
a_rep = repeating_groundtrack(k, m, w_E, mu_E);

% Cartesian Parameters of the orbit with repeating groundtrack
[r_rep,v_rep] = kep2car(a_rep, e0, i0, OM0, om0, th0, mu_E);

T_orbit_rep = 2*pi*sqrt(a_rep^3/mu_E);      % Orbital period of the modified orbit[s]
tspan_rep = 0:0.1:T_orbit_rep;              % Set the tspan for the ODE solver

% Calling the function Groundtrack.m I can compute the Longitude and
% Latitude of the s/c in orbit
[alpha_rep,delta_rep,lon_rep,lat_rep] = groundtrack(a_rep,e0,i0,OM0,om0,th0, long0, k*tspan_rep, parameters, t0);

% Set longitude and latitude in degrees
lon_rep = rad2deg(lon_rep);
lat_rep = rad2deg(lat_rep);

% PLOT
figure()
hold on
cdata = imread('EarthTexture.jpg');
image(cdata, 'XData',[-180 180],'YData',[90 -90]);
plot( lon_rep, lat_rep,'r','LineStyle','none','Marker','.','MarkerSize',5)
plot( lon_rep(1), lat_rep(1),'g','Linewidth',2,'LineStyle','none','Marker','square','MarkerSize',15)
plot( lon_rep(end), lat_rep(end),'y','Linewidth',2,'LineStyle','none','Marker','o','MarkerSize',15)
grid on
xlim([-180,180])
ylim([-90,90])
xlabel('$Longitude$ $[degrees]$', 'FontSize',15)
ylabel('$Latitude$ $[degrees]$', 'FontSize',15)
legend('$Repeating$ $Ground-Track$','$Start$','$End$')
title('$Repeating$ $Ground-Track$','FontSize',20,'FontWeight','bold')

%% PERTURBED GROUND TRACK

% Ground-track of the nominal orbit considering the perturbations assigned 
[alpha_pert,delta_pert,lon_pert,lat_pert] = groundtrack_perturbed(a0,e0,i0,OM0,om0,th0,long0,tspan_gt,parameters,t0);

% Set longitude and latitude in degrees
lon_pert = rad2deg(lon_pert);
lat_pert = rad2deg(lat_pert);

% PLOT
figure()
hold on
cdata = imread('EarthTexture.jpg');
image(cdata, 'XData',[-180 180],'YData',[90 -90]);
plot( lon_pert, lat_pert,'r','LineStyle','none','Marker','.')
plot( lon_pert(1), lat_pert(1),'g','Linewidth',2,'LineStyle','none','Marker','square','MarkerSize',10)
plot( lon_pert(end), lat_pert(end),'y','Linewidth',2,'LineStyle','none','Marker','o','MarkerSize',10)
grid on
xlim([-180,180])
ylim([-90,90])
xlabel('$Longitude$ $[degrees]$', 'FontSize',15)
ylabel('$Latitude$ $[degrees]$', 'FontSize',15)
legend('$Ground-Track$','$Start$','$End$')
title('$Perturbed$ $Ground-Track$','FontSize',20)

%% PERTURBED & REPEATING GROUND TRACK

% Ground-track of the modified orbit considering the perturbations assigned 
[alpha_pert_rep,delta_pert_rep,lon_pert_rep,lat_pert_rep] = groundtrack_perturbed(a_rep,e0,i0,OM0,om0,th0,long0,k*tspan_rep,parameters,t0);

% Set longitude and latitude in degrees
lon_pert_rep = rad2deg(lon_pert_rep);
lat_pert_rep = rad2deg(lat_pert_rep);

% PLOT
figure()
hold on
cdata = imread('EarthTexture.jpg');
image(cdata, 'XData',[-180 180],'YData',[90 -90]);
plot( lon_pert_rep, lat_pert_rep,'r','LineStyle','none','Marker','.','MarkerSize',5)
plot( lon_pert_rep(1), lat_pert_rep(1),'g','Linewidth',2,'LineStyle','none','Marker','square','MarkerSize',10)
plot( lon_pert_rep(end), lat_pert_rep(end),'y','Linewidth',2,'LineStyle','none','Marker','o','MarkerSize',10)
grid on
xlim([-180,180])
ylim([-90,90])
xlabel('$Longitude$ $[degrees]$', 'FontSize',15,'Interpreter','latex')
ylabel('$Latitude$ $[degrees]$', 'FontSize',15,'Interpreter','latex')
legend('$Ground-Track$','$Start$','$End$','interpreter','latex')
title('$Perturbed$ $and$ $Repeated$ $Ground-Track$','FontSize',20,'Interpreter','latex')

%% ORBIT PROPAGATION

% Set the tspan for a well defined number of points over 100 periods 
n_orbit = 100;
step_T = 100;  % Step in seconds to create a well define number of points for each period
n_points = (n_orbit*T_orbit)/step_T+1;
tspan_orbit = linspace(0,n_orbit*T_orbit,n_points);

% Set options for the ODE solver
options = odeset( 'RelTol', 1e-13, 'AbsTol', 1e-14 );
kep_0 = [a0, e0, i0, OM0, om0, th0]';

% Propagation of the perturbed orbit by numerically integrating the equations of motion 
% in Cartesian coordinates
timer = tic;
[t_car, y_car] = ode113(@(t,y) ode_2bp_perturbed(t,y,parameters), tspan_orbit, y0, options);
timer_car = toc(timer);
% Propagation of the perturbed orbit using Gauss Equations
timer = tic;
[t_gau, KEP_gauss] = ode113(@(t,kep) ode_2bodyPerturbGauss(t,kep,parameters,'RSW'), tspan_orbit, kep_0, options);
timer_gauss = toc(timer);
% Transform the keplerian parameters in Cartesian coordinates
r_gauss = zeros(max(size(tspan_orbit)),3);
v_gauss = zeros(max(size(tspan_orbit)),3);
for j = 1:size(KEP_gauss,1)
    a = KEP_gauss(j,1);
    e = KEP_gauss(j,2);
    i = KEP_gauss(j,3);
    OM = KEP_gauss(j,4);
    om = KEP_gauss(j,5);
    th = KEP_gauss(j,6);
    [r,v] = kep2car(a, e, i, OM, om, th, mu_E);
    r_gauss(j,1:3) = r';
    v_gauss(j,1:3) = v';
end

% Transform the Cartesian coordinates in Keplerian parameters
r_v_car=y_car(:,1:3);
KEP_car = zeros(max(size(tspan_orbit)),6);
for z = 1:size(y_car,1)
    [a, e, i, OM, om, th] = car2kep(y_car(z,1:3), y_car(z,4:6), mu_E);
    KEP_car(z,:) = [a, e, i, OM, om, th];
end

% Plot of perturbed orbit in cartesian and gauss keplerian elements
figure()
plotPlanet(3,[0 0 0], gca, astroConstants(23)/astroConstants(3));
hold on;
%plot3(r_gauss(:,1),r_gauss(:,2),r_gauss(:,3),'LineStyle',':');
%plot3(r_v_car(:,1),r_v_car(:,2),r_v_car(:,3),'LineStyle',':');
clr = linspace(0,n_orbit,n_points)';
scatter3(r_v_car(:,1),r_v_car(:,2),r_v_car(:,3),10,clr);
cb = colorbar;
clim([0,100]);
title(cb,'$Time$ $[Periods]$','interpreter','latex')
title('$Perturbed$ $orbit$','FontSize',15,'Interpreter','latex')
xlabel('X[km]');
ylabel('Y[km]');
zlabel('Z[km]');
grid on

KEP_car(:,3:6) = unwrap(KEP_car(:,3:6));
KEP_gauss(:,3:6) = KEP_gauss(:,3:6) * 180/pi;
KEP_car(:,3:6) = KEP_car(:,3:6) * 180/pi;

%% MOOVIE orbit propagation 
% this section is only for a better visual approach, uncomment to see the
% evolution of the propagated orbit.
% figure()
% plotPlanet(3,[0 0 0], gca, astroConstants(23)/astroConstants(3));
% hold on;
% h = animatedline('Linewidth', 1);
% colormap(parula);
% colorData = linspace(1, n_points*n_orbit, n_points);
% k = plot3(nan,nan,nan,'or', 'MarkerFaceColor','r');
% step_animation = 5;
% t1 = linspace(0, n_points*n_orbit, n_points);
% % Initialize video
% myVideo = VideoWriter('myVideoFile'); %open video file
% myVideo.FrameRate = 10;  %can adjust this, 5 - 10 works well for me
% open(myVideo)
% 
% for i = 1:step_animation:length(t1)
% addpoints(h,r_v_car(i,1),r_v_car(i,2),r_v_car(i,3));
% set(k,'Xdata',r_v_car(i,1),'Ydata', r_v_car(i,2), 'Zdata', r_v_car(i,3));
% colorIndex = round(colorData(i));
% color = parula(n_points*n_orbit);  % Get the entire Parula colormap
% set(h, 'Color', color(colorIndex, :));
% drawnow
% frame = getframe(gcf); %get frame
% writeVideo(myVideo, frame);
% end
% close(myVideo)


%% FILTERING OF HIGH FREQUENCIES
step_T = 100;           % step for the tspan
n_orbit = 100;          % number of orbits
tspan_orbit = 1 : step_T : n_orbit*T_orbit;

T_cut = T_orbit; % see FSA notes for cut frequency
n_points = T_cut/step_T;
a_mean_ini = mean(KEP_gauss(1:floor(size(KEP_gauss,1)/n_orbit),1));

cc = parula(10);
% SEMI-MAJOR AXIS
a_filtered = movmean(KEP_gauss(:,1),n_points,"Endpoints","fill");
a_filtered(1:floor(n_points/2)) = a_mean_ini;
a_mean_fin = mean(a_filtered(end-floor(1.5*size(KEP_gauss,1)/n_orbit):end-floor(0.5*(size(KEP_gauss,1)/n_orbit))));
a_filtered(end-floor(n_points/2):end) = a_mean_fin;

% Plot
figure()
l = tiledlayout(1,2,'TileSpacing','compact');
title(l,'$SemiMajor$ $Axis$','FontSize',20,'interpreter','latex')
nexttile
plot(tspan_orbit/T_orbit,KEP_car(:,1),'Color',cc(1,:));
hold on;
plot(tspan_orbit/T_orbit,KEP_gauss(:,1),'Color',cc(2,:),'LineStyle','-.');
plot(tspan_orbit/T_orbit,a_filtered,'Color','r','LineWidth',1.5);
legend('$a_{Car}$','$a_{Gauss}$','$a_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$a$ $[Km]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,1) - KEP_gauss(:,1))/a0);
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|a_{Car}-a_{Gauss}|/a_0$')
title('$Relative$ $Error$','FontSize',15)
grid on

%% ECCENTRICITY
e_mean_ini = mean(KEP_gauss(1:floor(size(KEP_gauss,1)/n_orbit),2));

e_filtered = movmean(KEP_gauss(:,2),n_points,"Endpoints","fill");
e_filtered(1:floor(n_points/2)) = e_mean_ini;
e_mean_fin = mean(e_filtered(end-floor(1.5*size(KEP_gauss,1)/n_orbit):end-floor(0.5*(size(KEP_gauss,1)/n_orbit))));
e_filtered(end-floor(n_points/2):end) = e_mean_fin;

% Plot
figure()
l1 = tiledlayout(1,2,'TileSpacing','compact');
title(l1,'$Eccentricity$','FontSize',20,'interpreter','latex')
nexttile
plot(tspan_orbit/T_orbit,KEP_car(:,2),'Color',cc(1,:));
hold on;
plot(tspan_orbit/T_orbit,KEP_gauss(:,2),'Color',cc(2,:));
plot(tspan_orbit/T_orbit,e_filtered,'r','LineWidth',1.5);
legend('$e_{Car}$','$e_{Gauss}$','$e_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$e$ $[-]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)
grid on

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,2) - KEP_gauss(:,2)));
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|e_{Car}-e_{Gauss}|$')
title('$Relative$ $Error$')
grid on

% INCLINATION
i_mean_ini = mean(KEP_gauss(1:floor(size(KEP_gauss,1)/n_orbit),3));

i_filtered = movmean(KEP_gauss(:,3),n_points,"Endpoints","fill");
i_filtered(1:floor(n_points/2)) = i_mean_ini;
i_mean_fin = mean(i_filtered(end-floor(1.5*size(KEP_gauss,1)/n_orbit):end-floor(0.5*(size(KEP_gauss,1)/n_orbit))));
i_filtered(end-floor(n_points/2):end) = i_mean_fin;

% Plot
figure()
l2 = tiledlayout(1,2,'TileSpacing','compact');
title(l2,'$Inclination$','FontSize',20,'interpreter','latex')
nexttile
hold on;
plot(tspan_orbit/T_orbit,KEP_car(:,3),'Color',cc(1,:));
plot(tspan_orbit/T_orbit,KEP_gauss(:,3),'Color',cc(2,:),'Linestyle','-.');
plot(tspan_orbit/T_orbit,i_filtered,'r','LineWidth',1.5);
legend('$i_{Car}$','$i_{Gauss}$','$i_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$i$ $[Degree]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)
grid on

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,3) - KEP_gauss(:,3))/(360));
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|i_{Car}-i_{Gauss}|/2\pi$')
title('$Relative$ $Error$','FontSize',15)
grid on

% RIGHT ASCENSION OF ASCENDING NODES
coeff_OM_ini = (KEP_gauss(floor(size(KEP_gauss,1)/n_orbit),4) - KEP_gauss(1,4))/(tspan_orbit(floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(1));
OM_filtered = movmean(KEP_gauss(:,4),n_points,"Endpoints","fill");
OM_filtered(1:floor(n_points/2)) = OM0 + coeff_OM_ini.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit));
coeff_OM_fin = (KEP_gauss(end-floor(size(KEP_gauss,1)/n_orbit),4)-KEP_gauss(end,4))/(tspan_orbit(end-floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(end));
OM_filtered(end-floor(n_points/2):end) = OM_filtered(end-floor(n_points/2)-1)+coeff_OM_fin.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit)+1);

% Plot
figure()
l3 = tiledlayout(1,2,'TileSpacing','compact');
title(l3,'$Right$ $Ascension$ $of$ $Ascending$ $Nodes$','FontSize',20,'interpreter','latex')
nexttile
hold on;
plot(tspan_orbit/T_orbit,KEP_car(:,4),'Color',cc(1,:));
plot(tspan_orbit/T_orbit,KEP_gauss(:,4),'Color',cc(2,:));
plot(tspan_orbit/T_orbit,OM_filtered,'r','LineWidth',1.5);
legend('$\Omega_{Car}$','$\Omega_{Gauss}$','$\Omega_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$\Omega$ $[Degree]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)
grid on

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,4) - KEP_gauss(:,4))/(360));
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|\Omega_{Car}-\Omega_{Gauss}|/2\pi$')
title('$Relative$ $Error$','FontSize',15)
grid on

% ARGUMENT OF PERIGEE
coeff_om_ini = (KEP_gauss(floor(size(KEP_gauss,1)/n_orbit),5)-KEP_gauss(1,5))/(tspan_orbit(floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(1));
om_filtered = movmean(KEP_gauss(:,5),n_points,"Endpoints","fill");
om_filtered(1:floor(n_points/2)) = om0 + coeff_om_ini.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit));
coeff_om_fin = (KEP_gauss(end - floor(size(KEP_gauss,1)/n_orbit),5) - KEP_gauss(end,5))/(tspan_orbit(end - floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(end));
om_filtered(end-floor(n_points/2):end) = om_filtered(end - floor(n_points/2) - 1) + coeff_om_fin.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit) + 1);

% Plot
figure()
l4 = tiledlayout(1,2,'TileSpacing','compact');
title(l4,'$Argument$ $of$ $Perigee$','FontSize',20,'interpreter','latex')
nexttile
hold on;
plot(tspan_orbit/T_orbit,KEP_car(:,5),'Color',cc(1,:));
plot(tspan_orbit/T_orbit,KEP_gauss(:,5),'Color',cc(2,:));
plot(tspan_orbit/T_orbit,om_filtered,'r','LineWidth',1.5);
legend('$\omega_{Car}$','$\omega_{Gauss}$','$\omega_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$\omega$ $[Degree]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)
grid on

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,5) - KEP_gauss(:,5))/(360));
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|\omega_{Car}-\omega_{Gauss}|/2\pi$')
title('$Relative$ $Error$','FontSize',15)
grid on

% TRUE ANOMALY
coeff_th_ini = (KEP_gauss(floor(size(KEP_gauss,1)/n_orbit),6) - KEP_gauss(1,6))/(tspan_orbit(floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(1));
th_filtered = movmean(KEP_gauss(:,6),n_points,"Endpoints","fill");
th_filtered(1:floor(n_points/2)) = th0 + coeff_th_ini.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit));
coeff_th_fin = (KEP_gauss(end-floor(size(KEP_gauss,1)/n_orbit),6) - KEP_gauss(end,6))/(tspan_orbit(end-floor(size(KEP_gauss,1)/n_orbit))-tspan_orbit(end));
th_filtered(end-floor(n_points/2):end) = th_filtered(end-floor(n_points/2)-1) + coeff_th_fin.*tspan_orbit(1:floor(0.5*size(KEP_gauss,1)/n_orbit)+1);

% Plot
figure()
l5 = tiledlayout(1,2,'TileSpacing','compact');
title(l5,'$True$ $Anomaly$','FontSize',20,'interpreter','latex')
nexttile
hold on;
plot(tspan_orbit/T_orbit,KEP_car(:,6),'Color',cc(1,:));
plot(tspan_orbit/T_orbit,KEP_gauss(:,6),'Color',cc(2,:));
plot(tspan_orbit/T_orbit,th_filtered,'r','LineWidth',1.5);
legend('$\theta_{Car}$','$\theta_{Gauss}$','$\theta_{filtered}$');
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$\theta$ $[Degree]$')
title('$Comparison$ $Between$ $the$ $2$ $methods$','FontSize',15)
grid on

nexttile
semilogy(tspan_orbit/T_orbit,abs(KEP_car(:,6) - KEP_gauss(:,6))./abs(KEP_gauss(:,6)));
xlabel('$Number$ $of$ $T_{Orbit}$')
ylabel('$|\theta_{Car}-\theta_{Gauss}|/|\theta_{Gauss}|$')
title('$Relative$ $Error$','FontSize',15)
grid on

%% TIME PASSED BELOW 1000Km ALTITUDE

r_1000 = R_E + 1000; % radius @ 1000Km altitude [Km]
theta_1000 = acos(h^2/(mu_E*r_1000*e0)-1/e0); % True anomaly @r_1000 [rad]
E_1000 = 2*atan(sqrt((1-e0)/(1+e0))*tan(theta_1000/2)); % Eccentric Anomaly [rad]
M_e = E_1000 - e0*sin(E_1000); % Mean Anomaly [rad]
t_p_1000 = T_orbit*M_e/(2*pi); % Time passed from the pericentre below 1000Km altitude [s]
t_tot = 2*t_p_1000; % Total time below 1000Km altitude [s]
percentage = t_tot/T_orbit*100; % percentage of orbital period spent below 1000Km altitude

%% COMPARISON WITH REAL DATA
% Load the data of the Debris BREEZE-M DEB (TANK) (NORAD ID: 38344). We've
% chosen this debris as it is the one with the most similar orbital parameters to
% those one assigned to us
%
% We've picked up the ephemeris from 14/11/2023 to 24/11/2023, with a step
% of 1 minute
% 
DEBRIS_38344 = load('DEBRIS_38344.mat');
DEBRIS_38344 = DEBRIS_38344.TLEDEBRIS38344;
[kep_debris,car_debris] = sat_ephemeris(DEBRIS_38344,mu_E);

% Plot the orbit of the Debris-38344 using the ephemeris
figure()
plotPlanet(3,[0,0,0],gca,astroConstants(23)/astroConstants(3));
hold on
plot3(car_debris(:,1),car_debris(:,2),car_debris(:,3))

% Now I want to propagate the orbit using my model. To do so I need to pick
% the first value of my ephemeris
kep_debris0 = kep_debris(1,:)';
tspan_eph = linspace(1,10*24*60*60,max(size(kep_debris)));
[t_debris_gauss, kep_debris_gauss] = ode113(@(t,kep) ode_2bodyPerturbGauss(t,kep,parameters,'RSW'), tspan_eph, kep_debris0, options);

% Comparision between the downloaded ephemeris and the results of the
% propagation obtained through our model
% kep_debris(:,3:6) = unwrap(kep_debris(:,3:6));
kep_debris_gauss(:,6) = wrapTo2Pi(kep_debris_gauss(:,6));

% For the plot, we convert the tspan from seconds to days
tspan_eph_days = tspan_eph/(3600 * 24);

% Plot
u = tiledlayout(2,3,"TileSpacing","compact");
title(u,'$Comparison$ $between$ $Real$ $Data$ $and$ $Model$','FontSize',20,'interpreter','latex')

u1 = nexttile;
plot(u1,tspan_eph_days, kep_debris(:,1))
hold on
plot(u1,tspan_eph_days, kep_debris_gauss(:,1))
title('$Semi-Major$ $Axis$ $a$','FontSize',15)
xlabel('$Days$')
ylabel('$a$ $[Km]$')

% Eccentricity
u2 = nexttile;
plot(u2, tspan_eph_days, kep_debris(:,2))
hold on
plot(u2, tspan_eph_days, kep_debris_gauss(:,2))
title('$Eccentricity$ $e$','FontSize',15)
xlabel('$Days$')
ylabel('$e$')

% Inclination
u3 = nexttile;
plot(u3,tspan_eph_days, rad2deg(kep_debris(:,3)))
hold on
plot(u3,tspan_eph_days, rad2deg(kep_debris_gauss(:,3)))
title('$Inclination$ $i$','FontSize',15)
xlabel('$Days$')
ylabel('$i$ $[Degrees]$')

% Longitude of Ascending Node
u4 = nexttile;
plot(u4, tspan_eph_days, rad2deg(kep_debris(:,4)))
hold on
plot(u4, tspan_eph_days, rad2deg(kep_debris_gauss(:,4)))
title('$Longitude$ $of$ $Ascending$ $Node$ $\Omega$','FontSize',15)
xlabel('$Days$')
ylabel('$\Omega$ $[Degrees]$')

% Argument of Perigee
u5 = nexttile;
plot(u5, tspan_eph_days, rad2deg(kep_debris(:,5)))
hold on
plot(u5, tspan_eph_days, rad2deg(kep_debris_gauss(:,5)))
title('$Argument$ $of$ $Perigee$ $\omega$','FontSize',15)
xlabel('$Days$')
ylabel('$\omega$ $[Degrees]$')

% True Anomaly
u6 = nexttile;
plot(u6, tspan_eph_days, rad2deg(kep_debris(:,6)))
hold on
plot(u6, tspan_eph_days, rad2deg(kep_debris_gauss(:,6)))
title('$True$ $Anomaly$ $\theta$','FontSize',15)
xlabel('$Days$')
ylabel('$\theta$ $[Degrees]$')

lgd = legend('$Ephemerides$','$Gauss$');

