%% Assignement 1
clear; close all; clc;
addpath("functions\")
addpath("functions\textures\")
addpath("functions\timeConversion\time\")
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
%%
% running timer
tm = tic;

% Settings
set(groot, 'defaultTextInterpreter', 'latex')
set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
set(groot, 'defaultLegendInterpreter', 'latex')
set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
set(groot, 'defaultFigurePosition', [470, 360, 700, 430])
set(groot, 'defaultFigureColormap', turbo(256));
set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
set(groot,'defaultFigureColor',[1,1,1])
set(groot, 'defaultAxesColor', 'none');
set(groot, 'defaultAxesFontSize', 12);

%% DATA
% Departure:      Earth
% Fly-By:         Mercury
% Arrival:        Venus
% Time Windows:   % Min Departure: [2028 01 01 00 00 00]
                  % Max Arrival [2058 01 01 00 00 00]

% Physical Parameters

% Earth
mu_E = astroConstants(13); % [km^3/s^2]
R_E = astroConstants(23); % [km]
T_E = 365.256; % Orbit Sidereal Period [days]

% Venus
mu_V = astroConstants(12); % [km^3/s^2]
R_V = astroConstants(22);  % [km]
T_V = 224.7;                 % Orbit Sidereal Period [days]

% Mercury
mu_M = astroConstants(11); % [km^3/s^2]
R_M = astroConstants(21);  % [km]
T_M = 87.97;                 % Orbit Sidereal Period [days]

% Departure
dep_min = [2028 01 01 00 00 00];   % year, month, day, hours, minutes, seconds
dep_min = date2mjd2000(dep_min);   % mjd200 [day]
% Arrival 
arr_max = [2058 01 01 00 00 00];    % year, month, day, hours, minutes, seconds
land_max = date2mjd2000(arr_max);   % mjd200 [day]


%% Preliminary Analysis
% In this first approach the team try to find a repeted pattern for the
% possible deperture time and the optimal time of flight to go from Earth
% to Venus and from Venus to Mercury.
% In this section both transfer arch are considered indipendent each other,
% so the team conmpute the Porck-Chop Plots of the two manoeuvres.

% Compute the synodic periods 
T_syn_EV = (T_E*T_V)/(T_E - T_V); % Synodic Period bw Earth and Venus   [days]
T_syn_VM = (T_M*T_V)/(T_V - T_M); % Synodic Period bw Mercury and Venus [days]
T_syn_EM = (T_E*T_M)/(T_E - T_M); % Synodic Period bw Earth and Mercury [days]

% Data
ibody_M = 1;
ibody_V = 2;
ibody_E = 3;
step = 10;
departure_window = dep_min : step : land_max;
arrival_window = dep_min : step : land_max;

% --------------------------------------Earth Venus tranfer arch--------------------------------------------
% Analysis and Pork-chop plot
[deltaV_min_dep, DeltaV_TOT_dep, date_dep_E, date_arr_V] = PorkChop_plot_dep(ibody_E,ibody_V,departure_window,arrival_window);

% --------------------------------------Venus Mercury tranfer arch--------------------------------------------
[deltaV_min_arr, DeltaV_TOT_arr, date_dep_V, date_arr_M] = PorkChop_plot_arr(ibody_V,ibody_M,departure_window,arrival_window);



%% GRID SEARCH + Optimal grid results

%--------------------------------GRID SEARCH------------------------------
% From the preliminary analysis results we can observe that the best
% solutions for both transfer are time of flights under 300 days due to the low distance
% between the considered planets. We have also understand that every
% Eearth Venus synodic period the porck chop plot is repeted, so we choose to span the departure windows 
% with 20 points each synodic period ( around 1 possible departure at month)
% In these way we want to do a first research for the optimal solution

% ToFs and departure window
ToF1 = 50 : 10 : 300;
ToF2 = 20 : 10 : 200;
dep_time = dep_min : T_syn_EV/20 : land_max-ToF1(1)-ToF2(1);


% ---------------------------------Grid Search------------------------------
[del_v1,del_v2,del_v_p_hyp,D_v_tot,run_time] = GridSearch(dep_time,land_max,ToF1,ToF2);


%-------------------------------Best Results--------------------------------
% We choose the four best results of the grid search in order to do further
% optimization around those possible transfer windows

% Number of results to optimize
N_best = 5;

[DV,i1v,i2v,i3v] = Best_solutions(D_v_tot,N_best);


%% GENETIC ALGORITHM 1
% To obtain more more accurate solution the team used the matlab 'ga'
% which use a Genetic Algorithm to perform the optimal result.
% The team choose to implement it on all the four best results obtained
% from the grid search and then use the best solution.
% The genetic algorithm runs with all the possible ToF from the prelimnary
% analysis and with an intervall of two months around the possible
% departure windows.
% The 'ga' options are set to obtain a good convergence in a reasonable
% time.

% Option setting 
options = optimoptions('ga','MaxTime',3600, 'MaxStallGenerations', 50, 'FunctionTolerance', ...
                        1e-6, 'MaxGenerations', 500, 'NonlinearConstraintAlgorithm', 'penalty',...
                        'PopulationSize', 5000, 'Display', 'none', 'EliteCount', ceil(0.03*5000), 'UseParallel', false);
% Inizialization
DV_opt_v = zeros(1,N_best);
t_opt_v = zeros(N_best,3);

% Main
for it = 1:N_best  % for each solutions

    % Define the transfer windows
    i1 = i1v(it);
    ToF1 = 30:1:300;
    ToF2 = 10:1:200;
    dep_time_ga = dep_time(i1) - dep_min - 30 : 1 : dep_time(i1) - dep_min + 30;
    
    % Data for the Genetic Algorithm
    data.dep_min = dep_min;
    data.land_max = land_max;
    data.LB(1) = dep_time_ga(1);      
    data.LB(2) = ToF1(1);
    data.LB(3) = ToF2(1);
    data.UB(1) = dep_time_ga(end);
    data.UB(2) = ToF1(end);
    data.UB(3) = ToF2(end);    
    data.A = [1 1 1];
    data.B = land_max-dep_min;   
    data.isinter = 1:3; % integer problem
    
   %------------GENETIC ALGORITHM---------------------------------------
   [t_opt, DV_opt, comp_time] = GA_opt(data,options);
   % Results arrays
   DV_opt_v(it) = DV_opt;
   t_opt_v(it,:) = t_opt';

end

%%Best result
DV_opt = min(DV_opt_v);
opt_pos = find(DV_opt_v == DV_opt);
if length(opt_pos) > 1
    opt_pos = opt_pos(1);
end
t_opt = t_opt_v(opt_pos,:);  % Best Result from the GA's runs

%% GENETIC ALGORITHM 2
% To have a better precision on the final solution, the 'ga' function runs
% again with more stringent restrictions ( again two months precison for
% the departure window but 40 days span for teh first time of flight and 18
% day span for the second).
% This time 'ga' runs again with different options to obtain a better
% precision: the funciton presents non integer conditions and a
% minimization function, 'fmincon', that runs when the 'ga' terminates 


% Update of the genetic algorithm data
data.LB(1) = t_opt(1) - 30;
data.LB(2) = t_opt(2) - 20;
data.LB(3) = t_opt(3) - 9;
data.UB(1) = t_opt(1) + 30;
data.UB(2) = t_opt(2) + 20;
data.UB(3) = t_opt(3) + 9;
data.isinter = []; % non integer problem
 
% Update of the genetic algorithm options
options = optimoptions('ga','MaxTime',3600, 'MaxStallGenerations', 50, 'FunctionTolerance', ...
                        1e-5, 'MaxGenerations', 500, 'NonlinearConstraintAlgorithm', 'penalty','PlotFcn',{'gaplotbestindiv', 'gaplotbestf'},...
                        'PopulationSize', 1000, 'Display', 'none', 'EliteCount', ceil(0.01*1000), 'UseParallel', false);
% Hybrid function 'fmincon' options
hybirdopt = optimoptions(@fmincon,'PlotFcn',{'optimplotfval','optimplotx'},'Display','none');
% GA final options: ga options + hybrid options
options = optimoptions(options,'HybridFcn',{@fmincon,hybirdopt});

%-------------------------- GA second's run---------------------------------
[t_opt, DV_opt, ~] = GA_opt(data,options);
% Optimal results 

%% Mission Summary
% Dates of departure, Flyby and Arrival in MJD
Date_dep_mjd = dep_min + t_opt(1);                       %[mjd]
Date_flyby_mjd = dep_min + t_opt(1) + t_opt(2);          %[mjd]
Date_arr_mjd = dep_min + t_opt(1) + t_opt(2) +t_opt(3);  %[mjd]

% Results Summary
% The output structure of the function presents all the results obtained
% from the choosen mission.

[Results] = Interplanetary_Mission(Date_dep_mjd,Date_arr_mjd,Date_flyby_mjd);

%% Plot
% Figure 1 : Total Mission in the Heliocentric reference system
% Figure 2 : Fly-By in Venus reference system
Plot_Mission(Results,t_opt)
