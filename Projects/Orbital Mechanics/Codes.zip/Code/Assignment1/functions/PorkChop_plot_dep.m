function [deltaV_min_arr, DeltaV_TOT_arr, date_departure, date_arrival] = PorkChop_plot_dep(ibody_1,ibody_2,tspan_departure,tspan_arrival)
%
%  Lambert solver given a departure window and arrival window for a
%  transfer between planet 1 and planet 2 that outputs the minimum dv for
%  the transfer and the departure and arrival dates.
%
% PROTOTYPE
% [deltaV_min_arr, DeltaV_TOT_arr, date_departure, date_arrival] = PorkChop_plot_dep(ibody_1,ibody_2,tspan_departure,tspan_arrival)
%
%
% INPUT:
%	ibody1[1]    Integer number identifying the departure celestial body (< 11) [-]
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%                   10:  Sun
%   ibody2[1]    Integer number identifying the arrival celestial body [-]
%   departure_window [2x6]   Date matrix containing the time for the first and last possible times of departure
%                    Format: first row --> first departure time 
%                            second row --> last departure time
%   arrival_window  [2x6]    Date matrix containing the time for the first and last possible times of departure
%                   Format:  first row --> first arrival time 
%                            second row --> last arrival time 
%   v_infinite[1]            Maximum excess velocity from launcher in [km/s]
%   plot_results[1]          Binary variable to output or not the results and the contour of
%                            different dv. 
%                            If set to:
%                               - 0: plots only numerical results
%                               - 1: plots numerical results and porkchop
%                               plot
%                               - 2: does not plot anything
%  step[1]                   Discretization step [days]
%
%  OUTPUT:
%  dvmin[1]                  Minimum transfer cost [km/s]
%  departure                 Departure date in datetime format
%  arrival                   Arrival date in datetime format
%  dvtot_matrix              Matrix of different dv for all the combinations
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
%----------------------------------------------------------------------

DeltaV_TOT_arr = zeros(max(size(tspan_departure)), max(size(tspan_arrival)));

for i = 1 : length(tspan_departure)
    for j = 1 : length(tspan_arrival)
        
        %---------------------- DEPARTURE from planet 1 ---------------------
        mjd2000_1 = tspan_departure(i);
        % kep = [a e i Om om theta] [km, rad]
        % ksun = Gravity constant of the Sun [km^3/s^2]
        [kep_1,ksun] = uplanet(mjd2000_1, ibody_1);
        
        % INPUT
        a_1 = kep_1(1); %[Km]
        e_1 = kep_1(2);
        i_1 = kep_1(3); %[rad]
        OM_1 = kep_1(4); %[rad]
        om_1 = kep_1(5); %[rad]
        th_1 = kep_1(6); %[rad]

        % Transform the orbital coordinates in carthesian coordinates in
        % order to use the Lambert's function
        [r1,v1] = kep2car(a_1,e_1,i_1,OM_1,om_1, th_1, ksun);
        
        %----------------------ARRIVAL at planet 2 ---------------------------------
        mjd2000_2 = tspan_arrival(j);
        % kep = [a e i Om om theta] [km, rad]
        % ksun = Gravity constant of the Sun [km^3/s^2]
        [kep_2,ksun] = uplanet(mjd2000_2, ibody_2);
        
        % INPUT
        a_2 = kep_2(1);
        e_2 = kep_2(2);
        i_2 = kep_2(3);
        OM_2 = kep_2(4);
        om_2 = kep_2(5);
        th_2 = kep_2(6);
        

        % Transform the orbital coordinates in carthesian coordinates in
        % order to use the Lambert's function
        [r2,v2] = kep2car(a_2,e_2,i_2,OM_2,om_2, th_2, ksun);
        % Define the Time Of Flight 
        TOF_days = tspan_arrival(j) - tspan_departure(i);
        % Ephemerides functions take as input the date in days, while the
        % Lambert solver takes as input the time in seconds
        TOF = TOF_days * 24 * 60 * 60;

        % ------------------------------------- LAMBERT ARCh ------------------------------------------        
        [~,~,~,~,V1_t,V2_t,~,~] = lambertMR(r1,r2,TOF,ksun,0,0,0,0);
        % Compute the DeltaV of the INJECTION MANOEUVRE
        deltaV_1 = norm(V1_t' - v1); % deltaV injection manoeuvre in the transfer orbit
        deltaV_2 = norm(v2 - V2_t');
        %deltaV_1(i,j) = deltaV_1;
        % Build the Delta V Matrix
       if TOF < 0 % Perchè le due time window si sovrappongono
           DeltaV_TOT_arr(i,j) = NaN;
       else
           DeltaV_TOT_arr(i,j) = deltaV_1 + deltaV_2;

       end
   end
end
% Now I need to find the minimum DeltaV_TOT and the correnspondant
% departure date and arrival date

% min(A) con A matrice rende un vettore riga con i minimi di ogni colonna 
% di A. Per trovare il minimo di tutta la matrice devo usare due volte min
[pos_row_min, pos_column_min] = find(DeltaV_TOT_arr==min(min(DeltaV_TOT_arr))); 
deltaV_min_arr = min(min(DeltaV_TOT_arr));

% DeltaV_TOT Matrix[123x183] --> n. righe = tempi partenza; 
% n.colonne = tempi di arrivo
Date_departure_min_mjd = tspan_departure(pos_row_min);
Date_arrival_min_mjd = tspan_arrival(pos_column_min);
% Trasformo le due date in calendario gregoriano da MJD2000
date_departure = mjd20002date(Date_departure_min_mjd);
date_arrival = mjd20002date(Date_arrival_min_mjd);

% For the porkchop plot:
% Use meshgrid to create 2-D grid coordinates based on the
% time discretizations for both departure and arrival.
startDate1 = datenum('01-01-2028', 'dd mmm yyyy');
startDate2 = datenum('01-01-2058', 'dd mmm yyyy');
endDate1 = datenum('01-01-2028',  'dd mmm yyyy');
endDate2 = datenum('01-01-2058',  'dd mmm yyyy');
xData = linspace(startDate1, startDate2, length(tspan_departure));
yData = linspace(endDate1, endDate2, length(tspan_arrival));
%   [X,Y] = meshgrid(x,y)
[T1_arr, T2_arr] = meshgrid(xData, yData);

figure()
[C,h] = contour(T1_arr, T2_arr, DeltaV_TOT_arr,0:25);
%clabel(C,h);
cb = colorbar;
title('$Pork-Chop$ $Plot$ $for$ $Earth-Venus$ $Transfer$','Fontsize',12,'interpreter','latex')
title(cb,'$\Delta{V}_{TOT}$ $[\frac{Km}{s}]$','interpreter','latex')
xlabel('$Departure$ $Date$','interpreter','latex')
ylabel('$Arrival$ $Date$','interpreter','latex')
datetick('x', 'dd-mmm-yyyy', 'keeplimits', 'keepticks')
datetick('y', 'dd-mmm-yyyy', 'keeplimits', 'keepticks')
grid on
hold on

end