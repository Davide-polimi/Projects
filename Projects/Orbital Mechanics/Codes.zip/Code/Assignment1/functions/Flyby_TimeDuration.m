function [Flyby_time,Results] = Flyby_TimeDuration(Results,r_SOI,mu_Planet)
% the function evaluate the time span for the fly-by, the time span are calculated from the stay within the sphere of influence of Venus.
%
% PROTOTYPE
% [Flyby_time,Results] = Flyby_TimeDuration(Results,r_SOI,mu_Planet)
%
% INPUT:
% Results:  stucture  see "Interplanetary_Misssion" outupts
% r_SOI:    scalar    Rasius of the sphere of influence [km]
% mu_Planet scalar    planetary constant [km^3/s^2]
%
% OUTPUT    
% Flyby_time  scalar     Time of stay within the Planet's SOI [s]
% Results     structure  Update results 
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version

e_hyp_entry = Results.Flyby_parameters.e_hyp_entry;
e_hyp_exit = Results.Flyby_parameters.e_hyp_exit;
a_hyp_entry = Results.Flyby_parameters.a_hyp_entry;
a_hyp_exit = Results.Flyby_parameters.a_hyp_exit;

% Compute the true anomaly when we enter in the Sphere of Influence of Venus
% Hyperbola Equation: r_SOI = p/(1 + ecos(theta_minus)
% INGOING LEG OF THE HYPERBOLA --> theta is negative
p_hyp_entry = a_hyp_entry * (1 - e_hyp_entry^2);
th_inf_minus = acos((p_hyp_entry/r_SOI - 1)/e_hyp_entry);
% Hyperbolic Anomaly [rad]
E_minus = 2*atanh(sqrt((e_hyp_entry - 1)/(1 + e_hyp_entry)) * tan(-th_inf_minus/2));
% Mean Anomaly [rad]
M_minus = e_hyp_entry * sinh(E_minus) - E_minus; 
t_minus = M_minus * sqrt(-a_hyp_entry^3/mu_Planet);
% This is the time needed to reach the perigee of the hyperbola starting
% from the beginning of the Venus' Sphere of Influence

% Compute the true anomaly when we enter in the Sphere of Influence of Venus
% Hyperbola Equation: r_SOI = p/(1 + ecos(theta_minus)
% OUTGOING LEG OF THE HYPERBOLA --> theta is positive
p_hyp_exit = a_hyp_exit * (1 - e_hyp_exit^2);
th_inf_plus = acos((p_hyp_exit/r_SOI - 1)/e_hyp_exit);
% Hyperbolic Anomaly [rad]
E_plus = 2*atanh(sqrt((e_hyp_exit - 1)/(1 + e_hyp_exit)) * tan(th_inf_plus/2));
% Mean Anomaly [rad]
M_plus = e_hyp_exit * sinh(E_plus) - E_plus; 
t_plus = M_plus * sqrt(-a_hyp_exit^3/mu_Planet);
% This is the time needed to reach the end of the Venus' Sphere of
% Influence starting from the pericentre of the hyperbola

Flyby_time = t_plus + abs(t_minus); % Time needed to perform the Powered Fly-By [s]
s = seconds(Flyby_time);

s.Format = 'hh:mm:ss.SSS';
hours_fb = hours(s);
Results.Flyby_parameters.t_minus = abs(t_minus);
Results.Flyby_parameters.t_plus = t_plus;
Results.Flyby_parameters.Flyby_Duration = s;
Results.Flyby_parameters.Flyby_Duration_hours = hours_fb;
end