function [del_v1,del_v2,del_v_p_hyp,D_v_tot,run_time] = GridSearch(dep_time,t_arr,ToF1,ToF2)
% ----------------------------------------------------------------------------------
% Function to evaluate with a preliminary approximation the Delta V of the
% interplanetary mission assigned (Departure from Earth - fly-by at Venus -
% Arrival at Mercury).
%
% PROTOTYPE
% [del_v1,del_v2,del_v_p_hyp,D_v_tot,run_time] = GridSearch(dep_time,t_arr,ToF1,ToF2)
%
% INPUT
% dep_time[n_pointx1]       Departure time vector in MJD2000 with a defined step [day]
% t_arr   [1]               Maximum arrival time at Mercury in MJD2000 [day]
% ToF1    [n_pointx1]       Time of flight from Earth to Venus in MJD2000 [day]
% Tof2    [n_pointx1]       Time of flight from Venus to Mercury in MJD2000 [day]
%
% OUTPUT
% del_v1[nxn]           Delta velocity array for the first labert arch [km/s]
% del_v2[nxn]           Delta velocity array for the second labert arch [km/s]
% del_v_p_hyp[nxnxn]    Delta velocity array for the GA fly by [km/s]
% D_v_tot[nxnxn]        Delta velocity array of the complete mission [km/s]
% run_time [1]          Running time of the GridSearch  function [s]
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version

time = tic;
% Initialization and Physical Parameters
mu_S = astroConstants(4);
del_v1 = ones(length(dep_time),length(ToF1))*Inf;
del_v2 = ones(length(dep_time),length(ToF1),length(ToF2))*Inf;
t_after_fl = zeros(length(dep_time),length(ToF1));
t_arrival  = zeros(length(dep_time),length(ToF1),length(ToF2));
D_v_tot = ones(length(dep_time),length(ToF1),length(ToF2))*Inf;
del_v_p_hyp = ones(length(dep_time),length(ToF1),length(ToF2))*Inf;
h_min_flyby = 500;

% Grid Search
for k = 1:length(dep_time)      % for each departure time                                                               
    t1 = dep_time(k);      
%---------------------Earth keplerian parameters at departure time --------------------
    % Earth keplerian parameters at departure time 
    [kep_E,~] = uplanet(t1, 3);                                                            
    [r_E,V_E] = kep2car(kep_E(1),kep_E(2),kep_E(3),kep_E(4),kep_E(5),kep_E(6),mu_S);      

    for j = 1: length(ToF1)     % for each possible ToF from Earth to Venus
        % time control
        tof1 = ToF1(j);
        t_after_fl(k,j) = t1+tof1;  % Time in mjd200 at the fly by

        if t_after_fl(k,j) <= t_arr
            %--------------- Venus keplerian parameters at the fly by --------------------    
            % Venus keplerian parameters at the fly by
            [kep_V,~] = uplanet(t_after_fl(k,j), 2);
            [r_V,v_V] = kep2car(kep_V(1),kep_V(2),kep_V(3),kep_V(4),kep_V(5),kep_V(6),mu_S);   % Venus orbitl parameters
  
            % Transformation in seconds for lambert
            tof1 = tof1*24*60*60;                                                                

            %--------------------------LAMBERT ARC ---------------------------------------
            [~,~,~,~,V_E_exit,V_V_entry,~,~] = lambertMR(r_E,r_V,tof1,mu_S,0,0,0);             
            %   V_E_exit: Heliocentric velocity of the s/c at departure from Earth 
            %   V_V_entry: Heliocentric velocity of the s/c at arrival at Venus
            % Delta Velocity needed to enter in the Earth-Venus Transfer Orbit
            del_v_E = V_E_exit'- V_E;
            dv_tot_n = norm(del_v_E); 
            del_v1(k,j) = dv_tot_n;

            for w = 1 : length(ToF2)    % for each possible ToF from Venus to Mercury
                tof2 = ToF2(w);
                % Landing time in mjd2000
                t_arrival(k,j,w) = t_after_fl(k,j) + tof2; % Arrival Date on Mercury in MJD2000 

                if t_arrival(k,j,w) <= t_arr
                    %------------------- Mercury keplerian parameters at landing time ----------------
                    [kep_M,~] = uplanet(t_arrival(k,j,w), 1);
                    [r_M,V_M] = kep2car(kep_M(1),kep_M(2),kep_M(3),kep_M(4),kep_M(5),kep_M(6),mu_S);
     
                    % Transformation in seconds for lambert
                    tof2 = tof2*24*60*60;   

                    %----------------------------LAMBERT ARC-------------------------
                    [~,~,~,~,v_V_exit,V_M_entry,~,~] = lambertMR(r_V,r_M,tof2,mu_S,0,0,0);
                    % Second Delta Velocity
                    del_V_M =  V_M_entry'- V_M;
                    dv2_norm = norm(del_V_M);
                    del_v2(k,j,w) = dv2_norm;
                    %------------------------ FLY-BY ----------------------------------------
                    [~,deltaV_p_hyp,~,~] = Fly_By_ga(astroConstants(22),v_V,V_V_entry,v_V_exit,astroConstants(12),h_min_flyby);
                    del_v_p_hyp(k,j,w) = deltaV_p_hyp;

                    % Total Delta V
                    D_v_tot(k,j,w) = del_v1(k,j) + del_v2(k,j,w) + del_v_p_hyp(k,j,w) ;

                end
            end
        end
    end
end

run_time = toc(time);

end