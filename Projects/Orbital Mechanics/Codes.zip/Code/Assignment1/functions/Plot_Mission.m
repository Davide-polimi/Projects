function Plot_Mission(Results,t_opt)
% ------------------------------------------------------------------------
% Show the plot of the results
% Figure 1 : Total Mission in the Heliocentric reference system
% Figure 2 : Fly-By in Venus reference system
%
% PROTOTYPE
% Plot_Mission(Results,t_opt)
%
% INPUT
% Results   strcuture          Mission Results (check Interplanetary_Mission)
% t_opt       array   [3x1]   time vector with times respectivly:
%                              the minimum departure from Earth, time of    [s]
%                              flight Earth-Venus, time of flight
%                              Venus_mercury
%
% OUTPUT  -none-
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
%-------------------------------------------------------------------------

% ode set
options = odeset( 'RelTol', 1e-13, 'AbsTol', 1e-14 );

% Phisical parameters
mu_sun = astroConstants(4);
mu_V = astroConstants(12);

%------------------Departure Orbit - Earth-------------------------------
R_E = Results.Lambert_arc.r_Earth;
V_E = Results.Lambert_arc.V_Earth;
a_E = 1/( 2/norm(R_E) - dot(V_E,V_E)/mu_sun ); % Semi-major axis [km]
T_E = 2*pi*sqrt( a_E^3/mu_sun );
tspan_E = linspace(0,T_E,1000);
y0_E = [R_E ; V_E];
[ ~, Y_E] = ode113( @(t,y) ode_2bp(t,y,mu_sun,0,0), tspan_E, y0_E, options  );

%-------------------Fly-By Orbit - Venus----------------------------------
R_V = Results.Lambert_arc.r_Venus;
V_V =  Results.Lambert_arc.V_Venus;
a_V = 1/( 2/norm(R_V) - dot(V_V,V_V)/mu_sun ); % Semi-major axis [km]
T_V = 2*pi*sqrt( a_V^3/mu_sun );
tspan_V = linspace(0,T_V,1000);
y0_V = [R_V ; V_V];
[ ~, Y_V] = ode113( @(t,y) ode_2bp(t,y,mu_sun,0,0), tspan_V, y0_V, options  );

%---------------- Arrival Oribit - Mercury--------------------------------
R_M = Results.Lambert_arc.r_Mercury;
V_M =  Results.Lambert_arc.V_Mercury;
a_M = 1/( 2/norm(R_M) - dot(V_M,V_M)/mu_sun ); % Semi-major axis [km]
T_M = 2*pi*sqrt( a_M^3/mu_sun );
tspan_V = linspace(0,T_M,1000);
y0_M = [R_M ; V_M];
[ ~, Y_M] = ode113( @(t,y) ode_2bp(t,y,mu_sun,0,0), tspan_V, y0_M, options  );

%-------------------- First Lambert Arc-----------------------------------
V_E_exit = Results.Lambert_arc.V_fb_exit;
y0_t1 = [ R_E; V_E_exit ];             

a_t1 = 1/( 2/norm(R_E) - dot(V_E_exit,V_E_exit)/mu_sun ); % Semi-major axis [km]
T_t1 = 2*pi*sqrt( a_t1^3/mu_sun );
tspan_t1 = linspace(0,T_t1,1000);
tspan_t1_tf = linspace(0,t_opt(2)*24*60*60,1000);

% Perform the integration
[~, Y_t1] = ode113(@(t,y) ode_2bp(t, y, mu_sun,0,0), tspan_t1, y0_t1, options);
[~, Y_t1_tf] = ode113(@(t,y) ode_2bp(t, y, mu_sun,0,0), tspan_t1_tf, y0_t1, options);

%------------------- Second Lambert Arc------------------------------------
V_M_entry = Results.Lambert_arc.V_fb_arrival;
y0_t2 = [ R_M; V_M_entry ];             

a_t2 = 1/( 2/norm(R_M) - dot(V_M_entry,V_M_entry)/mu_sun ); % Semi-major axis [km]
T_t2 = 2*pi*sqrt( a_t2^3/mu_sun );
tspan_t2 = linspace(0,T_t2,1000);
tspan_t2_tf = linspace( t_opt(3)*24*60*60,0,1000);

% Perform the integration
[~, Y_t2] = ode113(@(t,y) ode_2bp(t, y, mu_sun,0,0), tspan_t2, y0_t2, options);
[~, Y_t2_tf] = ode113(@(t,y) ode_2bp(t, y, mu_sun,0,0), tspan_t2_tf, y0_t2, options);

%% Fly-By
a_hyp_entry = Results.Flyby_parameters.a_hyp_entry;
a_hyp_exit = Results.Flyby_parameters.a_hyp_exit;
r_p = Results.Flyby_parameters.r_p;
r_p_vec = Results.Flyby_parameters.r_p_vector;
v_p_plus_vec = Results.Flyby_parameters.v_p_plus_vec;
v_p_minus_vec = Results.Flyby_parameters.v_p_minus_vec;
vinf_minus = Results.Flyby_parameters.v_inf_minus;
vinf_plus = Results.Flyby_parameters.v_inf_plus;
t_minus = Results.Flyby_parameters.t_minus;
t_plus = Results.Flyby_parameters.t_plus;

% Plot the asymptote
centre_1 = (-a_hyp_entry+r_p)*r_p_vec/norm(r_p_vec);
centre_2 = (-a_hyp_exit+r_p)*r_p_vec/norm(r_p_vec);
x_2 = linspace(centre_2(1), 4e04, 10000);
y_as_2 = vinf_plus(2)/vinf_plus(1)*(x_2-centre_2(1))+centre_2(2);
z_as_2 = vinf_plus(3)/vinf_plus(1)*(x_2-centre_2(1))+centre_2(3);

x_1 = linspace(centre_1(1), -3.5e04, 10000);
y_as_1 = vinf_minus(2)/vinf_minus(1)*(x_1-centre_1(1))+centre_1(2); 
z_as_1 = vinf_minus(3)/vinf_minus(1)*(x_1-centre_1(1))+centre_1(3);


x_peri = linspace(-centre_1(1)*1.5,centre_1(1)*2, 1000);
y_peri = r_p_vec(2)/r_p_vec(1)*x_peri;
z_peri = r_p_vec(3)/r_p_vec(1)*x_peri;

% tspan for the ODE propagation
tspan_hyp = linspace(0,t_plus,10000);
tspan_hyp_retro = linspace(t_minus,0,10000);

% Set options for the ODE solver
options = odeset('RelTol',1e-13, 'AbsTol', 1e-14);
y_hyp_minus = [r_p_vec, v_p_minus_vec];
[~, Y_hyp_minus] = ode113(@(t,y) ode_2bp(t,y,mu_V,0,0), tspan_hyp_retro, y_hyp_minus, options);
y_hyp_plus = [r_p_vec, v_p_plus_vec];
[~, Y_hyp_plus] = ode113(@(t,y) ode_2bp(t,y,mu_V,0,0), tspan_hyp, y_hyp_plus, options);









%% PLOT 1 :  INTERPLANETARY MISSION

figure("Color","k")
% backgroundImage = imread('Background.jpeg');  
% hold on;
% im = imshow(backgroundImage, 'XData', [-1 1], 'YData', [-1 1]);
% uistack(im,"bottom")
view(31.5575,29.6791)
grid on

ax = gca; 
ax.GridAlpha = 0.2; 
ax.GridColor = [0.5 0.5 0.5];
ax.Color = 'k';
ax.XColor = 'white';
ax.YColor = 'white';
ax.ZColor = 'white';


% Planets
plotPlanet(10,[0 0 0]',gca,20);
hold on
plotPlanet(3,R_E,gca,12);
plotPlanet(2,R_V,gca,12);
plotPlanet(1,R_M,gca,12);

% Orbits
plot3(Y_E(:,1), Y_E(:,2), Y_E(:,3),'--b','LineWidth',0.5);
plot3(Y_V(:,1), Y_V(:,2), Y_V(:,3),'--y','LineWidth',0.5);
plot3(Y_M(:,1), Y_M(:,2), Y_M(:,3),'--m','LineWidth',0.5);
plot3(Y_t1(:,1), Y_t1(:,2), Y_t1(:,3),':g','LineWidth',0.5)
plot3(Y_t2(:,1), Y_t2(:,2), Y_t2(:,3),':c','LineWidth',0.5)
plot3(Y_t1_tf(:,1), Y_t1_tf(:,2), Y_t1_tf(:,3),'-g','LineWidth',2)
plot3(Y_t2_tf(:,1), Y_t2_tf(:,2), Y_t2_tf(:,3),'-c','LineWidth',2)

xlabel('$X$ $[km]$','Color','w')
ylabel('$Y$ $[km]$','Color','w')
zlabel('$Z$ $[km]$','Color','w')
title('$INTERPLANETARY$ $MISSION$','FontSize',22,'Color','w')
legend('SUN','EARTH','VENUS','MERCURY','Earth Orbit','Venus Orbit','Mercury Orbit', ...
       '','','First Lambert Arc','Second Lambert Arc', ...
       'Location','bestoutside','TextColor','white')


%% Figures for the report
dep_t = Results.Dates.dep_mjd;
fb_t = Results.Dates.flyby_mjd;
arr_t = Results.Dates.arr_mjd;

% Positions
[kep_E_fb,k_sun] = uplanet(fb_t,3);
[kep_E_arr,~] = uplanet(arr_t,3);
[kep_V_dep,~] = uplanet(dep_t,2);
[kep_V_arr,~] = uplanet(arr_t,2);
[kep_M_dep,~] = uplanet(dep_t,1);
[kep_M_fb,~] = uplanet(fb_t,1);

[R_E_fb,~] = kep2car(kep_E_fb(1),kep_E_fb(2),kep_E_fb(3),kep_E_fb(4),kep_E_fb(5),kep_E_fb(6),k_sun);
[R_E_arr,~] = kep2car(kep_E_arr(1),kep_E_arr(2),kep_E_arr(3),kep_E_arr(4),kep_E_arr(5),kep_E_arr(6),k_sun);
[R_V_dep,~] = kep2car(kep_V_dep(1),kep_V_dep(2),kep_V_dep(3),kep_V_dep(4),kep_V_dep(5),kep_V_dep(6),k_sun);
[R_V_arr,~] = kep2car(kep_V_arr(1),kep_V_arr(2),kep_V_arr(3),kep_V_arr(4),kep_V_arr(5),kep_V_arr(6),k_sun);
[R_M_dep,~] = kep2car(kep_M_dep(1),kep_M_dep(2),kep_M_dep(3),kep_M_dep(4),kep_M_dep(5),kep_M_dep(6),k_sun);
[R_M_fb,~] = kep2car(kep_M_fb(1),kep_M_fb(2),kep_M_fb(3),kep_M_fb(4),kep_M_fb(5),kep_M_fb(6),k_sun);

%% Global mission withe 
figure("Color","w")
grid on
view(17.2854,22.4593);
% Planets
plotPlanet(10,[0 0 0]',gca,20);
hold on
plotPlanet(3,R_E,gca,12);
plotPlanet(2,R_V,gca,12);
plotPlanet(1,R_M,gca,12);

% Orbits
plot3(Y_E(:,1), Y_E(:,2), Y_E(:,3),'--b','LineWidth',1);
plot3(Y_V(:,1), Y_V(:,2), Y_V(:,3),'--y','LineWidth',1);
plot3(Y_M(:,1), Y_M(:,2), Y_M(:,3),'--m','LineWidth',1);
plot3(Y_t1(:,1), Y_t1(:,2), Y_t1(:,3),':g','LineWidth',1)
plot3(Y_t2(:,1), Y_t2(:,2), Y_t2(:,3),':c','LineWidth',1)
plot3(Y_t1_tf(:,1), Y_t1_tf(:,2), Y_t1_tf(:,3),'-g','LineWidth',2.5)
plot3(Y_t2_tf(:,1), Y_t2_tf(:,2), Y_t2_tf(:,3),'-c','LineWidth',2.5)

xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
title('$INTERPLANETARY$ $MISSION$','FontSize',22,'Color','k')
legend('SUN','EARTH','VENUS','MERCURY','Earth Orbit','Venus Orbit','Mercury Orbit', ...
       '','','First Lambert Arc','Second Lambert Arc', ...
       'Location','bestoutside','TextColor','k')

%% Departure time
figure("Color","w")
grid on
% Planets
plotPlanet(10,[0 0 0]',gca,20);
hold on
plotPlanet(3,R_E,gca,12);
plotPlanet(2,R_V_dep,gca,12);
plotPlanet(1,R_M_dep,gca,12);

% Orbits
plot3(Y_E(:,1), Y_E(:,2), Y_E(:,3),'--b','LineWidth',1);
plot3(Y_V(:,1), Y_V(:,2), Y_V(:,3),'--y','LineWidth',1);
plot3(Y_M(:,1), Y_M(:,2), Y_M(:,3),'--m','LineWidth',1);
plot3(Y_t1(:,1), Y_t1(:,2), Y_t1(:,3),':g','LineWidth',1)
plot3(Y_t1_tf(:,1), Y_t1_tf(:,2), Y_t1_tf(:,3),'-g','LineWidth',2.5)

xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
title('$Departure$','FontSize',22,'Color','k')
legend('SUN','EARTH','VENUS','MERCURY','Earth Orbit','Venus Orbit','Mercury Orbit', ...
       '','First Lambert Arc', ...
       'Location','bestoutside','TextColor','k')

%% First Lambert Arc (fly by time)
figure("Color","w")
grid on

% Planets
plotPlanet(10,[0 0 0]',gca,20);
hold on
plotPlanet(3,R_E_fb,gca,12);
plotPlanet(2,R_V,gca,12);
plotPlanet(1,R_M_fb,gca,12);

% Orbits
plot3(Y_E(:,1), Y_E(:,2), Y_E(:,3),'--b','LineWidth',1);
plot3(Y_V(:,1), Y_V(:,2), Y_V(:,3),'--y','LineWidth',1);
plot3(Y_M(:,1), Y_M(:,2), Y_M(:,3),'--m','LineWidth',1);
plot3(Y_t1(:,1), Y_t1(:,2), Y_t1(:,3),':g','LineWidth',1)
plot3(Y_t2(:,1), Y_t2(:,2), Y_t2(:,3),':c','LineWidth',1)
plot3(Y_t1_tf(:,1), Y_t1_tf(:,2), Y_t1_tf(:,3),'-g','LineWidth',2.5)
plot3(Y_t2_tf(:,1), Y_t2_tf(:,2), Y_t2_tf(:,3),'-c','LineWidth',2.5)

xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
title('$Flyby$','FontSize',22,'Color','k')
legend('SUN','EARTH','VENUS','MERCURY','Earth Orbit','Venus Orbit','Mercury Orbit', ...
       '','','First Lambert Arc','Second Lambert Arc', ...
       'Location','bestoutside','TextColor','k')

%% Second Lmbert Arc (arrival time)
figure("Color","w")
grid on

% Planets
plotPlanet(10,[0 0 0]',gca,20);
hold on
plotPlanet(3,R_E_arr,gca,12);
plotPlanet(2,R_V_arr,gca,12);
plotPlanet(1,R_M,gca,12);

% Orbits
plot3(Y_E(:,1), Y_E(:,2), Y_E(:,3),'--b','LineWidth',1);
plot3(Y_V(:,1), Y_V(:,2), Y_V(:,3),'--y','LineWidth',1);
plot3(Y_M(:,1), Y_M(:,2), Y_M(:,3),'--m','LineWidth',1);
plot3(Y_t1(:,1), Y_t1(:,2), Y_t1(:,3),':g','LineWidth',1)
plot3(Y_t2(:,1), Y_t2(:,2), Y_t2(:,3),':c','LineWidth',1)
plot3(Y_t1_tf(:,1), Y_t1_tf(:,2), Y_t1_tf(:,3),'-g','LineWidth',2.5)
plot3(Y_t2_tf(:,1), Y_t2_tf(:,2), Y_t2_tf(:,3),'-c','LineWidth',2.5)

xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
title('$Arrival$','FontSize',22,'Color','k')
legend('SUN','EARTH','VENUS','MERCURY','Earth Orbit','Venus Orbit','Mercury Orbit', ...
       '','','First Lambert Arc','Second Lambert Arc', ...
       'Location','bestoutside','TextColor','k')



%% PLOT 2: FLY BY

%% VENUS SOI
figure("Color","w")
% Venus
plotPlanet(2,[0;0;0],gca,astroConstants(22)/astroConstants(3));
hold on
axis equal
% Incoming and Outgoing Archs
plot3(Y_hyp_minus(:,1),Y_hyp_minus(:,2),Y_hyp_minus(:,3),'b','LineWidth',1.5)
plot3(Y_hyp_plus(:,1),Y_hyp_plus(:,2),Y_hyp_plus(:,3),'r','LineWidth',1.5)
% Asymptotes
plot3(x_1,y_as_1,z_as_1,'--r','LineWidth',1)
plot3(x_2,y_as_2,z_as_2,'--b','LineWidth',1)
% Apse line
plot3(x_peri,y_peri,z_peri,'-.','Color','k','LineWidth', 1)
grid on
grid minor
xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
legend('$Venus$','$Incoming$ $Hyperbola$','$Outgoing$ $Hyperbola$','$Incoming$ $Asymptote$','$Outgoing$ $Asymptote$','', ...
    'Location','northwest')
title('$Fly-By$ $Venus$ $SOI$','FontSize',22,'Color','k')

%% Zoom on Venus
figure()
view(-2.062427004050527e+02,25.847683254505071)
% Venus
plotPlanet(2,[0;0;0],gca,astroConstants(22)/astroConstants(3));
hold on

xlim([-3 3]*1e4);
ylim([-3 3]*1e4);
zlim([-3 3]*1e4);
% Incoming and Outgoing Archs
plot3(Y_hyp_minus(:,1),Y_hyp_minus(:,2),Y_hyp_minus(:,3),'b','LineWidth',1.5)
plot3(Y_hyp_plus(:,1),Y_hyp_plus(:,2),Y_hyp_plus(:,3),'r','LineWidth',1.5)
% Asymptotes
plot3(x_1,y_as_1,z_as_1,'--r','LineWidth',1)
plot3(x_2,y_as_2,z_as_2,'--b','LineWidth',1)
% Apse line
plot3(x_peri,y_peri,z_peri,'-.','Color','k','LineWidth', 1)
grid on
grid minor
xlabel('$X$ $[km]$')
ylabel('$Y$ $[km]$')
zlabel('$Z$ $[km]$')
legend('Venus','$Incoming$ $Hyperbola$','$Outgoing$ $Hyperbola$','$Incoming$ $Asymptote$','$Outgoing$ $Asymptote$','','Location','bestoutside')
title('$Fly-By$ $Venus$','FontSize',22,'Color','k')








end









