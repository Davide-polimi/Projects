function v_rotated = Rodrigues_formula(v,u,delta)

% Function to rotate a vector v of an angle delta around the unit vector u
% counter-clockwise
%
% PROTOTYPE
% v_rotated = Rodrigues_formula(velocity,unit versor, delta)
%
% INPUT
% v [3x1]        vector we want to rotate [km/s]
% u [3x1]        unit vector around which v is rotating [-]
% delta [1]      angle of which v is rotate [rad]
%
% OUTPUT
% v_rotated [3x1]  vector rotated [km/s]
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version

v_rotated = v.*cos(delta) + (cross(u,v).*sin(delta)) + u.*(dot(u,v)).*(1-cos(delta));

end