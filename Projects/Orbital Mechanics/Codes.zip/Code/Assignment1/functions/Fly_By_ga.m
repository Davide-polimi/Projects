function [DeltaV_flyby,deltaV_p_hyp,r_p,Results] = Fly_By_ga(R_planet,V_planet,V_entry,V_exit,mu_planet,h_min_flyby)
% ----------------------------------------------------------------------------------
% Function for the Fly-by. Given the values of s/c heliocentric velocity
% and the planet's parameters, we compute the Delta V gained with the
% fly-by and the Delta V that need to be impressed at the hyperbola's
% pericentre to link the two Lambert Arcs calculated previously.
%
% PROTOTYPE
% [DeltaV_flyby,deltaV_p_hyp,r_p,Results] = Fly_By_ga(R_planet,V_planet,V_entry,V_exit,mu_planet,h_min_flyby)
%
% INPUT
% R_Planet[1x1]  Radius of the planet where wqe perform the fly-by (astroconstants(2..)) [km]
% V_planet[3x1]  Velocity of the planet when we perform the fly-by (calculated with uplanet.m) [km/s]
% V_entry[1x3]   s/c Velocity wrt the Sun at the end of the first Lambert arc.
%                So it's the heliocentric velocity of the s/c incoming in the
%                hyperbola before the fly-by.[km/s]
% V_exit[1x3]    s/c Velocity wrt the Sun outgoing from the hyperbola after the fly-by.
%                So it's the velocity at the beginning of the second Lambert arc.[km/s]
% mu_planet      Gravitational constant of the planet around which we perform the fly-by [Km^2/s^3] 
% h_min_flyby    Minimum Altitude at the pericentre of the Hyperbola due to
%                Venus atmosphere [km]
%
% OUTPUT
% DeltaV_flyby[1x1]   Delta V obtained performing the fly-by [km/s]
% deltaV_p_hyp[1x1]   Delta V impressed at the common pericentre needed to combine 
%                     the two hyperbolic arcs. This is necessary to match
%                     the two interplanetary arcs obtained from Lambert's
%                     problem. If it is 0, this means that the fly-by could
%                     be performed with a single hyperbolic arc.[km/s]
% r_p[1x1]            Magnitude of the hyperbola's radius of pericentre [km]
% Flyby_parameters    Matlab structure with all the variables needed for the plot
%                     - r_p:  Magnitude of the hyperbola's radius of
%                     pericentre [km]
%                     - r_p_vec: Vector of hyperbola's radius of pericentre [km]
%                     - a_hyp_entry: Semi-major Axis of the incoming leg of
%                       the hyperbola [km]
%                     - a_hyp_exit: Semi-major Axis of the outgoing leg of the 
%                       hyperbola [km]
%                     - v_p_minus_vec: Velocity vector @ pericentre of the
%                       incoming hyperbola [km/s]
%                     - v_p_plus_vec: Velocity vector @ pericentre of the
%                       outgoing hyperbola [km/s]
%                       
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
% ---------------------------------------------------------------------------------- 
% Initialization
Results.Flyby_parameters.r_p = NaN;
Results.Flyby_parameters.r_p_vector = NaN;
Results.Flyby_parameters.a_hyp_entry = NaN;
Results.Flyby_parameters.a_hyp_exit = NaN;
Results.Flyby_parameters.e_hyp_entry = NaN;
Results.Flyby_parameters.e_hyp_exit = NaN;
Results.Flyby_parameters.v_p_minus_vec = NaN;
Results.Flyby_parameters.v_p_plus_vec = NaN;







% Definition of V Infinite Plus and V Infinite Minus. 
vinf_minus = V_entry' - V_planet;
vinf_minus_norm = vecnorm(vinf_minus')';
vinf_plus = V_exit' - V_planet;
vinf_plus_norm = vecnorm(vinf_plus')';

% Turn Angle: Angle between the two aymptotes
turn_angle = acos(dot(vinf_minus,vinf_plus)./(vinf_minus_norm .* vinf_plus_norm));

% Recovering with fzero the magnitude of the pericenter radius
turnangle_minus  = @(r_p) 2*asin(1./(1+ r_p * vinf_minus_norm^2/mu_planet));
turnangle_plus   = @(r_p) 2*asin(1./(1+ r_p * vinf_plus_norm^2/mu_planet));
r_p_SolveFun = @(r_p) (turnangle_minus(r_p) + turnangle_plus(r_p))/2 - turn_angle;
r_p_min = R_planet + h_min_flyby; 
r_p = fzero(r_p_SolveFun, r_p_min, optimset('Display','none'));

if r_p >= r_p_min
% Definition of the direction of the radius of pericentre
% Unit Vector u: direction orthogonal to the plane of the hyperbola
u = cross(vinf_minus,vinf_plus)/norm(cross(vinf_minus,vinf_plus));
% Turn angle of the incoming hyperbolic arc
turnangle_minus = 2*asin(1./(1+ r_p * vinf_minus_norm^2/mu_planet));
% The direction of the radius of pericentre is the same of the Delta V in
% the case of the non-powered fly-by. So I compute the V Infinite Plus
% in the case of a non-powered fly-by.
vinf_plus_np = Rodrigues_formula(vinf_minus,u,turnangle_minus); % Non-Powered hyp vinf_plus
deltaV_np = vinf_plus_np - vinf_minus;
r_p_direction = - deltaV_np/norm(deltaV_np);

r_p_vec = r_p * r_p_direction; % Radius of Pericentre Vector
% Compute the velocities of the 2 hyperbolic arcs @ pericentre and the
% DeltaV needed to perform the manoeuvre at the pericentre
% To compute the velocities, I caan use the eq of Energy
e_hyp_exit = 1 + r_p*vinf_plus_norm^2/mu_planet;
a_hyp_exit = -mu_planet/vinf_plus_norm^2;
e_hyp_entry = 1 + r_p*vinf_minus_norm^2/mu_planet;
a_hyp_entry = -mu_planet/vinf_minus_norm^2;
% eq of Energy => -mu/2*a + mu/r_p = v_p^2/2

v_p_minus = sqrt(2*mu_planet/r_p - mu_planet/a_hyp_entry); % Velocity at pericentre of incoming hyp's arc
v_p_minus_vec =  v_p_minus * cross(r_p_direction,u);
v_p_plus = sqrt(2*mu_planet/r_p - mu_planet/a_hyp_exit); % Velocity at pericentre of outgoing hyp's arc
v_p_plus_vec = v_p_plus * cross(r_p_direction,u);
% Delta V we need to impress @pericentre to perform a powered Fly-By
deltaV_p_hyp = abs(v_p_plus - v_p_minus);

% Delta V gained through the fly-by
DeltaV_flyby_vec = vinf_plus - vinf_minus;
DeltaV_flyby = norm(DeltaV_flyby_vec);

Results.Flyby_parameters.r_p = r_p;
Results.Flyby_parameters.r_p_vector = r_p_vec;
Results.Flyby_parameters.a_hyp_entry = a_hyp_entry;
Results.Flyby_parameters.a_hyp_exit = a_hyp_exit;
Results.Flyby_parameters.e_hyp_entry = e_hyp_entry;
Results.Flyby_parameters.e_hyp_exit = e_hyp_exit;
Results.Flyby_parameters.v_p_minus_vec = v_p_minus_vec;
Results.Flyby_parameters.v_p_plus_vec = v_p_plus_vec;
Results.Flyby_parameters.v_inf_minus = vinf_minus;
Results.Flyby_parameters.v_inf_plus = vinf_plus;


else
    r_p = NaN;
    deltaV_p_hyp = NaN;
    DeltaV_flyby = NaN;
end





% % Plot
% % Plot the asymptote
% centre_1 = (-a_hyp_entry+r_p)*r_p_vec/norm(r_p_vec);
% centre_2 = (-a_hyp_exit+r_p)*r_p_vec/norm(r_p_vec);
% x_2 = linspace(centre_2(1), 7e04, 1000);
% y_as_2 = vinf_plus(2)/vinf_plus(1)*(x_2-centre_2(1))+centre_2(2);
% z_as_2 = vinf_plus(3)/vinf_plus(1)*(x_2-centre_2(1))+centre_2(3);
%
% x_1 = linspace(centre_1(1), -4e04, 1000);
% y_as_1 = vinf_minus(2)/vinf_minus(1)*(x_1-centre_1(1))+centre_1(2); 
% z_as_1 = vinf_minus(3)/vinf_minus(1)*(x_1-centre_1(1))+centre_1(3);
% 
% 
% x_peri = linspace(0,centre_1(1), 1000);
% y_peri = r_p_vec(2)/r_p_vec(1)*x_peri;
% z_peri = r_p_vec(3)/r_p_vec(1)*x_peri;
%
% % tspan for the ODE propagation
% tspan_hyp = linspace(0,5000,1000);
% tspan_hyp_retro = linspace(5000,0,1000);
% 
% tspan_plus = linspace(0,15000000,1000);
% tspan_minus = linspace(15000000,0,1000);
% 
% % Set options for the ODE solver
% options = odeset('RelTol',1e-13, 'AbsTol', 1e-14);
% y_hyp_minus = [r_p_vec, v_p_minus_vec];
% [T_hyp_minus, Y_hyp_minus] = ode113(@(t,y) ode_2bp(t,y,mu_planet), tspan_hyp_retro, y_hyp_minus, options);
% y_hyp_plus = [r_p_vec, v_p_plus_vec];
% [T_hyp_plus, Y_hyp_plus] = ode113(@(t,y) ode_2bp(t,y,mu_planet), tspan_hyp, y_hyp_plus, options);
% 
% figure()
% plotPlanet(3,[0;0;0],gca,astroConstants(23)/astroConstants(3))
% hold on
% plot3(Y_hyp_minus(:,1),Y_hyp_minus(:,2),Y_hyp_minus(:,3),'b','LineWidth',1.5)
% plot3(Y_hyp_plus(:,1),Y_hyp_plus(:,2),Y_hyp_plus(:,3),'r','LineWidth',1.5)
% plot(x_1,y_as_1,z_as_1, 'LineWidth', 2)
% plot3(x_2,y_as_2,z_as_2, 'g', 'LineWidth',2)
% plot3(x_peri,y_peri,z_peri,'--','Color','k','LineWidth', 1.5)
% grid on
% xlabel('$X$ $[AU]$','Interpreter','latex')
% ylabel('$Y$ $[AU]$','Interpreter','latex')
% zlabel('$Z$ $[AU]$','Interpreter','latex')
% legend('','$Incoming$ $Hyperbola$','$Outgoing$ $Hyperbola$','$Incoming$ $Asymptote$','$Outgoing$ $Asymptote$','','Interpreter','latex')
end
