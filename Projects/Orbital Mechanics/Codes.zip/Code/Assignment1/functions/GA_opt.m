function [t_opt, DV_opt, comp_time] = GA_opt(data,options)
%----------------------------------------------------------------------------
% optimizationGA - the function minimizes an objective function [fitness],
% using the genetic algorithm routines, to obtain the optimal time windows 
% for departure, fly by and arrival
%
% PROTOTYPE
% [t_opt, DV_opt, comp_time] = GA_opt(data,options)
%
% INPUTS:
%  data        struct  [1x1]   general data struct                          [-]
%  options     struct  [1x1]   options struct                               [-]
% 
% OUTPUTS:
%  t_opt       array   [3x1]   time vector with times respectivly:
%                              the minimum departure from Earth, time of    [s]
%                              flight Earth-Venus, time of flight
%                              Venus_mercury
%  DV_opt      scalar          Total delta velocity for the t_opt window    [m/s]                           
% 
%
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
%                   
% -------------------------------------------------------------------------
% run time
ti = tic;
%
dep_min = data.dep_min;

% Fitness constrains
A = data.A;
B = data.B;   

% Lower and upper bounds 
LB(1) = data.LB(1);
LB(2) = data.LB(2);
LB(3) = data.LB(3);

UB(1) = data.UB(1);
UB(2) = data.UB(2);
UB(3) = data.UB(3);

isint = data.isinter;
% fitness function
fit_fnc = @(x) fit(x, A, B, dep_min);


%% Genetic Algorithm
[t_opt, DV_opt, ~] = ga(fit_fnc, 3, [], [], [], [], LB, UB, [],isint, options);

comp_time = toc(ti);

end


%% FITNESS FUNCTION
% gneration of the fitness function to optimize
function DV = fit(x, A, B,dep_min)
% control
contr = sum(A.*x);
% minimum altitude from Venus
h_min_flyby = 500;
    if contr <= B
    [kep_dep, k_sun] = uplanet((dep_min + x(1)),3);
    [r_dep, v_dep] = kep2car(kep_dep(1),kep_dep(2),kep_dep(3),kep_dep(4),kep_dep(5),kep_dep(6), k_sun);

    [kep_FlyBy, ~] = uplanet((dep_min + x(2) + x(1)), 2);
    [r_FlyBy, V_planet] = kep2car(kep_FlyBy(1),kep_FlyBy(2),kep_FlyBy(3),kep_FlyBy(4),kep_FlyBy(5),kep_FlyBy(6), k_sun);

    [kep_arr, ~] = uplanet((dep_min + x(3)+ x(2)+ x(1)), 1);
    [r_arr, v_arr] = kep2car(kep_arr(1),kep_arr(2),kep_arr(3),kep_arr(4),kep_arr(5),kep_arr(6), k_sun);

    TOF1 = x(2)*24*60*60;
    TOF2 = x(3)*24*60*60;

    % DEPARTURE
    [~, ~, ~,~, vi1, vf1,~, ~] = lambertMR(r_dep, r_FlyBy, TOF1, k_sun, 0, 0, 0, 0);
    DV1 = norm(vi1' - v_dep);
    
    % ARRIVAL
    [~, ~, ~, ~, vi2, vf2, ~, ~] = lambertMR(r_FlyBy, r_arr, TOF2, k_sun, 0, 0, 0, 0);
    DV2 = norm(vf2' - v_arr);
    
    % FLY-BY
    [~,deltaV_p_hyp,~,~ ] = Fly_By_ga(astroConstants(22),V_planet,vf1,vi2,astroConstants(12),h_min_flyby);
    % Delta V total
    DV = DV1 + DV2 + deltaV_p_hyp;
        
    else
        DV = NaN;
    end

end






