function [Results] = Interplanetary_Mission(Date_dep_mjd,Date_arr_mjd,Date_flyby_mjd)
% ----------------------------------------------------------------------------------
% Function to compute the Delta V and all the parameters of interest of the
% interplanetary mission assigned (Departure from Earth - fly-by at Venus -
% Arrival at Mercury).
%
% PROTOTYPE
%[Results] = Interplanetary_Mission(Date_dep_mjd,Date_arr_mjd,Date_flyby_mjd)
%
% INPUT
% Date_dep[1]      Exact departure date from Earth                           [day]
% Date_arr[1]      Exact arrival date on Mercury                             [day]
% Date_flyby[1]    Exact date when the flyby will be performed around Venus  [day]
%
% OUTPUT
% Results       Matlab structure with all the results of interest. Divided
%               into three sub-structures:
%               - DeltaV: [km/s]
%                   - DeltaV_min: minimum Total DeltaV obtained for the mission 
%                     (DeltaV_min = DeltaV1_opt + DeltaV2_opt + DeltaV_p_hyp)
%                   - DeltaV1: DeltaV we need to give in order to insert in the 
%                     Earth-Venus transfer arc in the optimal condition
%                   - DeltaV2: DeltaV we need to give in order to insert in an 
%                     orbit around Mercury from a Venus-Mercury transfer arc
%                     in the optimal condition
%                   - DeltaV_p_hyp: DeltaV we need to impress @ pericentre
%                     of the hyperbola to perform the right powered Fly-By around
%                     Venus
%                   - DeltaV_flyby: Total DeltaV gained thanks to the Powered
%                     Fly-by
%                - Flyby_parameters: 
%                   - r_p:  Magnitude of the hyperbola's radius of
%                   pericentre [km]
%                   - r_p_vec: Vector of hyperbola's radius of pericentre [km]
%                   - a_hyp_entry: Semi-major Axis of the incoming leg of
%                     the hyperbola [km]
%                   - a_hyp_exit: Semi-major Axis of the outgoing leg of the 
%                     hyperbola [km]
%                   - v_p_minus_vec: Velocity vector @ pericentre of the
%                     incoming hyperbola [km/s]
%                   - v_p_plus_vec: Velocity vector @ pericentre of the
%                     outgoing hyperbola [km/s]
%                 - Lambert Arc:
%                   - r_E: Earth position vector wrt Sun [km]
%                   - V_E: Earth Velocity wrt Sun [km/s]
%                   - r_V: Venus position vector wrt Sun [km]
%                   - V_V: Venus Velocity wrt Sun [km/s]
%                   - r_M: Mercury position vector wrt Sun [km]
%                   - V_M: Mercury Velocity wrt Sun [km/s]
%                 - Dates:
%                   - Date_departure: Mission Departure Date from Earth
%                   [day]
%                   - Date_arrival: Mission Arrival Date on Mercury [day]
%                   - Date_flyby: Date when we perform the powered fly-by
%                   around Venus [day]
% 
% CONTRIBUTORS
% Davide Bellini
% Edoardo Mensi Weingrill
% Pietro Mirri
% Gabriele Nuccio
%
% VERSION
% 27-12-2023: First Version
% ---------------------------------------------------------------------------------- 

% PHYSICAL PARAMETERS
% EARTH
ibody_E = 3; % Planet ID needed for the function uplanet.m
% VENUS
R_V = astroConstants(22); % Venus Radius [Km]
mu_V = astroConstants(12); % Venus Gravitational Constant
ibody_V = 2; % Planet ID needed for the function uplanet.m
% MERCURY
ibody_M = 1; % Planet ID needed for the function uplanet.m
% SUN
mu_S = astroConstants(4); % Sun Gravitational Constant


% Define the two Time of Flight
ToF1 = Date_flyby_mjd - Date_dep_mjd; % ToF of the Earth-Venus Lambert Arc [days]
ToF1_sec = ToF1 * 24 * 3600;  % ToF in seconds
ToF2 = Date_arr_mjd - Date_flyby_mjd; % ToF of the Venus-Mercury Lambert Arc [days]
ToF2_sec = ToF2 * 24 * 3600;
  
%---------------------Earth keplerian parameters at departure time --------------------
[kep_E,~] = uplanet(Date_dep_mjd, ibody_E);                                                            
% kep_E => Earth keplerian parameters: a, e, i, OM, om, theta
[r_E,V_E] = kep2car(kep_E(1),kep_E(2),kep_E(3),kep_E(4),kep_E(5),kep_E(6),mu_S);      
%   r_E: Earth position vector wrt Sun
%   V_E: Earth Velocity wrt Sun

%------------------------ Venus keplerian parameters at the fly by --------------------    
[kep_V,~] = uplanet(Date_flyby_mjd, ibody_V);
% kep_V => Venus keplerian parameters: a, e, i, OM, om, theta
[r_V,V_V] = kep2car(kep_V(1),kep_V(2),kep_V(3),kep_V(4),kep_V(5),kep_V(6),mu_S);
%   r_V: Venus position vector wrt Sun
%   V_V: Venus Velocity wrt Sun
                                                           
%----------------------------- LAMBERT ARC ------------------------------------------------
[~,~,~,~,V_E_exit,V_V_entry,~,~] = lambertMR(r_E,r_V,ToF1_sec,mu_S,0,0,0);             
%   V_E_exit: Heliocentric velocity of the s/c at departure from Earth 
%   V_V_entry: Heliocentric velocity of the s/c at arrival at Venus
% Delta Velocity needed to enter in the Earth-Venus Transfer Orbit
DeltaV_E = V_E_exit'- V_E; 
DeltaV_1 = norm(DeltaV_E); % DeltaV needed to insert in the Earth-Venus transfer arc

%---------------------------- Mercury keplerian parameters at landing time ----------------
[kep_M,~] = uplanet(Date_arr_mjd, ibody_M);
% kep_M => Mercury keplerian parameters: a, e, i, OM, om, theta
[r_M,V_M] = kep2car(kep_M(1),kep_M(2),kep_M(3),kep_M(4),kep_M(5),kep_M(6),mu_S);
%   r_M: Mercury position vector wrt Sun
%   V_M: Mercury Velocity wrt Sun
  
%-------------------------------------- LAMBERT ARC ---------------------------------------
[~,~,~,~,V_V_exit,V_M_entry,~,~] = lambertMR(r_V,r_M,ToF2_sec,mu_S,0,0,0);
%   V_V_exit: Heliocentric velocity of the s/c after the Fly-By around Venus 
%   V_M_entry: Heliocentric velocity of the s/c at arrival at Mercury
% Delta Velocity needed to enter in a non-defined Orbit around Mercury
DeltaV_M =  V_M_entry'- V_M;
DeltaV_2 = norm(DeltaV_M); % DeltaV needed to reach Mercury from the Venus-Mercury transfer arc

%------------------------------------------ FLY-BY ----------------------------------------
h_min_flyby = 500; % Minimum Altitude for Fly-By due to Venus atmosphere
[DeltaV_flyby,DeltaV_p_hyp,~,Results] = Fly_By_ga(R_V,V_V,V_V_entry,V_V_exit,mu_V,h_min_flyby);

[~,~,~,~,~,th1_t1,~] = car2kep(r_E,V_E_exit',mu_S);
[a_t1,e_t1,i_t1,OM_t1,om_t1,th2_t1,~] = car2kep(r_V,V_V_entry',mu_S);
[~,~,~,~,~,th1_t2,~] = car2kep(r_V,V_V_exit',mu_S);
[a_t2,e_t2,i_t2,OM_t2,om_t2,th2_t2,~] = car2kep(r_M,V_M_entry',mu_S);

DeltaV_TOT = DeltaV_1 + DeltaV_2 + DeltaV_p_hyp;

% FLY-BY TIME DURATION 
AU = astroConstants(2);
R_VS = 0.723 * AU; % Average Distance Venus-Sun
mu_S = astroConstants(4);
r_SOI = R_VS * (mu_V/mu_S)^(2/5);
[Flyby_time,Results] = Flyby_TimeDuration(Results,r_SOI,mu_V);

% Convert the dates from MJD2000 in Date
Date_dep = mjd20002date(Date_dep_mjd);
Date_flyby = mjd20002date(Date_flyby_mjd);
Date_arr = mjd20002date(Date_arr_mjd);

% Structure with all the outputs

Results.DeltaV.DeltaV_TOT = DeltaV_TOT;
Results.DeltaV.DeltaV_1 = DeltaV_1;
Results.DeltaV.DeltaV_2 = DeltaV_2;
Results.DeltaV.DeltaV_pericentre_hyp = DeltaV_p_hyp;
Results.DeltaV.DeltaV_flyby = DeltaV_flyby;
Results.DeltaV.fb_rateo = DeltaV_p_hyp/DeltaV_flyby;
Results.Lambert_arc.r_Earth = r_E;
Results.Lambert_arc.V_Earth = V_E;
Results.Lambert_arc.r_Venus = r_V;
Results.Lambert_arc.V_Venus = V_V;
Results.Lambert_arc.r_Mercury = r_M;
Results.Lambert_arc.V_Mercury = V_M;
Results.Lambert_arc.V_fb_exit = V_E_exit';
Results.Lambert_arc.V_fb_arrival = V_M_entry';

Results.Lambert_arc.a_t1 = a_t1;
Results.Lambert_arc.e_t1 = e_t1;
Results.Lambert_arc.i_t1 = i_t1;
Results.Lambert_arc.OM_t1 = rad2deg(OM_t1);
Results.Lambert_arc.om_t1 = rad2deg(om_t1);
Results.Lambert_arc.th1_t1 = rad2deg(th1_t1);
Results.Lambert_arc.th2_t1 = rad2deg(th2_t1);

Results.Lambert_arc.a_t2 = a_t2;
Results.Lambert_arc.e_t2 = e_t2;
Results.Lambert_arc.i_t2  = rad2deg(i_t2);
Results.Lambert_arc.OM_t2 = rad2deg(OM_t2);
Results.Lambert_arc.om_t2 = rad2deg(om_t2);
Results.Lambert_arc.th1_t2 = rad2deg(th1_t2);
Results.Lambert_arc.th2_t2 = rad2deg(th2_t2);


Results.Dates.Date_departure = Date_dep;
Results.Dates.Date_arrival = Date_arr;
Results.Dates.Date_flyby = Date_flyby;
Results.Dates.Flyby_time = Flyby_time;
Results.Dates.dep_mjd = Date_dep_mjd;
Results.Dates.flyby_mjd = Date_flyby_mjd;
Results.Dates.arr_mjd = Date_arr_mjd;



end